Площадки, на которых запрещены показы

# Площадки, на которых запрещены показы

Внимание

Исключение площадок и сетей может привести к неэффективной работе кампании и потере дополнительной аудитории, которую вы могли бы привлечь.

Экспериментируя с настройками кампании, вы можете запретить показ объявлений на выбранных площадках [Рекламной сети Яндекса](https://yandex.ru/support/direct/ru/general/yan) и [во внешних сетях](https://yandex.ru/support/direct/ru/general/yan#ssp). На поисковых проектах Яндекса запретить показы невозможно.

Всего можно исключить до 1000 доменов для баннеров и до 100 доменов для видеообъявлений.

Если вы внесете в список запрещенных площадок сайт, то объявления кампании не будут показываться как на тематических страницах этого сайта, так и в результатах поиска по нему. Во внешней сети можно запретить показы только на отдельных площадках (например, com.block.juggle/). Запретить показы в сетях целиком (например, Inner-active, BidSwitch, MoPub, MobFox, Smaato и других) не получится.

Добавить запрещенные площадки в [Мастере кампаний](https://yandex.ru/support/direct/ru/campaign-master/about) невозможно.

Посмотреть, на каких площадках были показы, можно в [Мастере отчетов](https://yandex.ru/support/direct/ru/statistics/new-reports-wizard), используя группировку **Название площадки**.

#### Остались вопросы?

Внимание

Специалисты отдела клиентского сервиса могут вас проконсультировать только по кампаниям того логина, с которого вы обращаетесь. Логин можно увидеть, если открыть [ya.ru](http://ya.ru/) на соседней вкладке браузера. Специалист получит доступ к вашим данным только при обработке обращения.

Сканируйте QR-код или нажмите на него для перехода по ссылке.

[![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/telegram-qr.png)](https://t.me/YandexDirectSupportBot?utm_source=direct&utm_medium=help&utm_campaign=ru)

[![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/watsapp-qr.png)](https://wa.me/74951399193?utm_source=direct&utm_medium=help&utm_campaign=ru)

При выборе Telegram, WhatsApp учитывайте, что Яндекс не контролирует, как сторонние мессенджеры хранят ваши данные и переписку на своей стороне, и не несет за это ответственность.

Написать в Viber

|     |     |
| --- | --- |
| [![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/rakuten-viber-qr.png)](https://yandex.ru/support/direct/ru/campaigns/viber:/chat?service=34368) | Для обращений из Республики Беларусь |

[Написать в чат](https://yandex.ru/chat#/user/840c4ce4-ed25-4c66-a7c7-ba8c001e02d9?utm_source=pay)

Позвонить

Клиентам и представителям агентств можно связаться с нами круглосуточно по телефонам:

**Регионы России**: [8 800 700-47-45](tel:88007004745) (звонок из России бесплатный)

**Москва**: [+7 495 139-91-93](tel:+74951399193)

**Беларусь**: [+375 17 336-31-36](tel:+375173363136)

Для доступа к кампаниям специалисту потребуется [PIN-код](https://yandex.ru/support/direct/ru/troubleshooting/pin-code)

Написать письмо

Клиентам

Агентствам

Другие вопросы по Директу — Яндекс Формы

\*

### Мой текущий логин совпадает с тем логином в Директе, по которому хочу задать вопрос

### \* Ваше имя Обязательное поле

### \* Email, на который будет отправлен ответ Обязательное поле

### Номер кампании

### \* Выберите тему обращения Обязательное поле

Модерация кампании

Другие вопросы по Директу

### \* Сообщение Обязательное поле

### Присоединить файл

Загрузить

До 10 файлов, допустимый общий размер файлов — 20 МБ.

![](https://ext.captcha.yandex.net/image?key=00AnLhDQMUKQRWcIRcv8RTqP1ee040cf)

Введите капчу

Отправить

[Формы обратной связи](https://yandex.ru/partner-office/knowledge-base)

### Полезные ссылки

- [Перейти в кабинет](https://direct.yandex.ru/)

- [Мои кампании](https://direct.yandex.ru/dna/grid/campaigns)

- [Вордстат](https://wordstat.yandex.ru/)

- [Способы оплаты](https://yandex.ru/support/direct/payments/payment-methods.html)

- [Контакты](https://yandex.ru/support/direct/contact-us.html)

- [Телеграм-канал Яндекс Рекламы](https://t.me/YANtech)

### Правовые документы

- [Требования к рекламным материалам](https://yandex.ru/legal/direct_adv_rules/ru/)

- [Правила показа](https://yandex.ru/legal/direct_display_rules/ru/)

- [Оферта](https://yandex.ru/legal/oferta_direct/ru/)

### Онлайн-обучение

- [Курсы по Директу](https://yandex.ru/adv/edu/online/direct)

- [Вебинары](https://yandex.ru/adv/edu/events)

- [Полезные материалы](https://yandex.ru/adv/edu/materials/tag-direct)

### Узнайте больше

- [Новости Директа](https://yandex.ru/adv/news?tag=direkt)

- [Кейсы клиентов Яндекса](https://yandex.ru/adv/solutions/cases)

- [Тренды и аналитика](https://yandex.ru/adv/solutions/analytics)

- [Мероприятия Яндекс Рекламы](https://yandex.ru/adv/meropriyatiya)

- [Телеграм-канал Яндекс Рекламы ПРО](https://t.me/yndx_ed)

### Была ли статья полезна?

ДаНет

- [Единая перфоманс-кампания](https://yandex.ru/support/direct/unified-performance-campaign/about "Единая перфоманс-кампания")
- [Реклама в мессенджерах](https://yandex.ru/support/direct/efficiency/messengers-ads "Реклама в мессенджерах")
- [Продвижение приложений](https://yandex.ru/support/direct/products-mobile-apps-ads/about "Продвижение приложений")
- [Медийная реклама](https://yandex.ru/support/direct/branding "Медийная реклама")
- [Мастер кампаний](https://yandex.ru/support/direct/campaign-master/about "Мастер кампаний")
- [Товарная кампания](https://yandex.ru/support/direct/campaign-master/product-campaign "Товарная кампания")
- [Простой старт](https://yandex.ru/support/direct/products-automatic/about "Простой старт")

- [Управление фидами](https://yandex.ru/support/direct/feeds/about "Управление фидами")
- [Таргетинги](https://yandex.ru/support/direct/impression-criteria/impression-criteria "Таргетинги")
- [Ретаргетинг](https://yandex.ru/support/direct/impression-criteria/retargeting-lists "Ретаргетинг")
- [Директ Коммандер](https://yandex.ru/support/direct/alternative-interfaces/direct-commander "Директ Коммандер")