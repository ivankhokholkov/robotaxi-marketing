  - [Inside App Scalingby Mintegral](https://www.businessofapps.com/channels/inside-app-scaling/)
  - [TVby Tatari](https://www.businessofapps.com/channels/tv/)
  - [Mobile Growthby Verve](https://www.businessofapps.com/channels/mobile-growth/)
  - [How I Grew Thisby Branch](https://www.businessofapps.com/channels/how-i-grew-this/)
  - [App Developmentby Designli](https://www.businessofapps.com/channels/app-development/)
  - [Web Monetizationby Paddle](https://www.businessofapps.com/channels/web-monetization/)
  - [Women in Mobileby Liftoff](https://www.businessofapps.com/channels/women-in-mobile/)
- [Media](https://www.businessofapps.com/data/app-retention-rates/#)
  - [Insights](https://www.businessofapps.com/insights/)
  - [Interviews](https://www.businessofapps.com/video/app-talks/)
  - [Video](https://www.businessofapps.com/video/)
  - [Podcast](https://www.businessofapps.com/podcasts/)
  - [Resources](https://www.businessofapps.com/resources/)
  - [Downloads](https://www.businessofapps.com/downloads/)
  - [App Leaders](https://www.businessofapps.com/app-leaders/)
  - [Guides](https://www.businessofapps.com/guides/)
  - [News](https://www.businessofapps.com/news)
- [Data](https://www.businessofapps.com/data/)
  - [App Benchmarks](https://www.businessofapps.com/data/app-benchmarks/)
  - [App Reports](https://www.businessofapps.com/data/app-reports/)
  - [App Market](https://www.businessofapps.com/data/app-market/)
  - [App Sectors](https://www.businessofapps.com/data/app-sectors/)
  - [App Stats](https://www.businessofapps.com/data/app-data/)
  - [App Rankings](https://www.businessofapps.com/data/app-rankings/)
- [Marketplace](https://www.businessofapps.com/marketplace/)
  - [App Marketing](https://www.businessofapps.com/marketplace/app-marketing/)
    - [AI Marketing](https://www.businessofapps.com/marketplace/ai-marketing/)
    - [Growth Marketing](https://www.businessofapps.com/marketplace/growth-marketing/)
    - [Mobile Marketing](https://www.businessofapps.com/marketplace/mobile-marketing/)
    - [Mobile Game Marketing](https://www.businessofapps.com/marketplace/mobile-game-marketing/)
    - [Performance Marketing](https://www.businessofapps.com/marketplace/performance-marketing/)
  - [User Acquisition](https://www.businessofapps.com/marketplace/user-acquisition/)
    - [eCommerce UA](https://www.businessofapps.com/marketplace/user-acquisition/ecommerce/)
    - [Games UA](https://www.businessofapps.com/marketplace/user-acquisition/games/)
    - [Demand Side Platforms](https://www.businessofapps.com/ads/mobile-dsp/)
    - [Influencer Marketing](https://www.businessofapps.com/marketplace/influencer-marketing/)
      - [Influencer Marketing Platforms](https://www.businessofapps.com/marketplace/influencer-marketing/platforms/)
      - [Influencer Marketing Agencies](https://www.businessofapps.com/marketplace/influencer-marketing/agencies/)
      - [Social Media Marketing](https://www.businessofapps.com/marketplace/social-media-marketing/)
      - [TikTok Marketing](https://www.businessofapps.com/marketplace/tiktok/)
    - [App Installs](https://www.businessofapps.com/ads/app-installs)
    - [Apple Search Ads](https://www.businessofapps.com/marketplace/apple-search-ads)
    - [Retargeting](https://www.businessofapps.com/ads/retargeting))
    - [CTV Ads](https://www.businessofapps.com/ads/ctv)
    - [OEM Advertising](https://www.businessofapps.com/marketplace/oem-advertising)
  - [App Store Optimization](https://www.businessofapps.com/marketplace/app-store-optimization/)
    - [ASO Tools](https://www.businessofapps.com/marketplace/app-store-optimization/aso-tools/)
    - [Apple Search Ads](https://www.businessofapps.com/marketplace/apple-search-ads/)
    - [App Conversion Rate Optimization](https://www.businessofapps.com/marketplace/app-conversion-rate-optimization)
  - [App Engagement](https://www.businessofapps.com/marketplace/app-engagement/)
    - [Marketing Automation](https://www.businessofapps.com/marketplace/marketing-automation/)
    - [Mobile CRM](https://www.businessofapps.com/marketplace/mobile-crm)
    - [In-app Messaging](https://www.businessofapps.com/marketplace/in-app-messaging/)
    - [Push Notifications](https://www.businessofapps.com/marketplace/push-notifications/)
  - [App Analytics](https://www.businessofapps.com/marketplace/app-analytics/)
    - [Mobile Attribution](https://www.businessofapps.com/marketplace/mobile-attribution/)
    - [Mobile Measurement Partners](https://www.businessofapps.com/marketplace/app-analytics/mobile-measurement-partners/)
    - [Crash Reporting](https://www.businessofapps.com/marketplace/crash-reporting/)
    - [App Monitoring](https://www.businessofapps.com/marketplace/application-monitoring/)
    - [A/B Testing](https://www.businessofapps.com/marketplace/app-analytics/ab-testing)
  - [App Monetization](https://www.businessofapps.com/marketplace/app-monetization/)
    - [Ad Servers](https://www.businessofapps.com/ads/ad-servers/)
    - [Mobile Game Monetization](https://www.businessofapps.com/marketplace/game-monetization)
    - [Subscription Platforms](https://www.businessofapps.com/marketplace/subscription)
    - [Paywall Platforms](https://www.businessofapps.com/marketplace/paywall)
    - [App Investors](https://www.businessofapps.com/marketplace/app-investors/)
  - [Mobile Advertising](https://www.businessofapps.com/ads/)
    - [Categories](https://www.businessofapps.com/ads/#directory)
      - [Mobile Ad Networks](https://www.businessofapps.com/ads/mobile-ad-network/)
      - [Ad Networks](https://www.businessofapps.com/ads/ad-networks/)
      - [CTV Advertising](https://www.businessofapps.com/ads/ctv-advertising/)
      - [Ad Fraud Tools](https://www.businessofapps.com/ads/ad-fraud/)
      - [Ad Servers](https://www.businessofapps.com/ads/ad-servers/)
      - [Mobile DSPs](https://www.businessofapps.com/ads/mobile-dsp/)
      - [Retargeting](https://www.businessofapps.com/ads/retargeting/)
    - [Ad Formats](https://www.businessofapps.com/ads/#directory)
      - [Content Lock](https://www.businessofapps.com/ads/content-lock/)
      - [In-App](https://www.businessofapps.com/ads/in-app/)
      - [Popunder](https://www.businessofapps.com/ads/popunder/)
      - [Rewarded Video](https://www.businessofapps.com/ads/rewarded-video/)
    - [Video](https://www.businessofapps.com/ads/video/)
    - [Models](https://www.businessofapps.com/ads/#directory)
      - [CPI](https://www.businessofapps.com/ads/cpi/)
      - [CPM](https://www.businessofapps.com/ads/cpm/)
      - [CPC](https://www.businessofapps.com/ads/cpc/)
      - [CTV](https://www.businessofapps.com/ads/ctv/)
  - [App Developers](https://www.businessofapps.com/app-developers/)
    - [Platforms](https://www.businessofapps.com/app-developers/#directory)
      - [AI](https://www.businessofapps.com/app-developers/artificial-intelligence/)
      - [Android](https://www.businessofapps.com/app-developers/android/)
      - [Augmented Reality](https://www.businessofapps.com/app-developers/augmented-reality/)
      - [Blockchain](https://www.businessofapps.com/app-developers/blockchain-developers/)
      - [Freelance](https://www.businessofapps.com/app-developers/freelance/)
      - [HTML5](https://www.businessofapps.com/app-developers/html5/)
      - [iOS](https://www.businessofapps.com/app-developers/ios/)
      - [IoT](https://www.businessofapps.com/app-developers/iot-developers/)
      - [Mobile Web](https://www.businessofapps.com/app-developers/mobile-web/)
      - [NFT](https://www.businessofapps.com/app-developers/nft-developers/)
      - [Web3](https://www.businessofapps.com/app-developers/web3-developers/)
      - [Browse all Platforms](https://www.businessofapps.com/app-developers/#directory)
    - [Countries](https://www.businessofapps.com/app-developers/#directory)
      - [Australia](https://www.businessofapps.com/app-developers/australia/)
      - [Canada](https://www.businessofapps.com/app-developers/canada/)
      - [India](https://www.businessofapps.com/app-developers/india/)
      - [UK](https://www.businessofapps.com/app-developers/uk/)
      - [USA](https://www.businessofapps.com/app-developers/usa/)
    - [Cities](https://www.businessofapps.com/app-developers/#directory)
      - [London](https://www.businessofapps.com/app-developers/london/)
      - [Los Angeles](https://www.businessofapps.com/app-developers/los-angeles/)
      - [Manchester](https://www.businessofapps.com/app-developers/manchester/)
      - [Miami](https://www.businessofapps.com/app-developers/miami/)
      - [New York](https://www.businessofapps.com/app-developers/nyc/)
      - [San Francisco](https://www.businessofapps.com/app-developers/san-francisco/)
      - [Toronto](https://www.businessofapps.com/app-developers/toronto/)
    - [Verticals](https://www.businessofapps.com/app-developers/#directory)
      - [Ecommerce](https://www.businessofapps.com/app-developers/ecommerce/)
      - [Education](https://www.businessofapps.com/app-developers/education/)
      - [Enterprise](https://www.businessofapps.com/app-developers/enterprise/)
      - [Entertainment](https://www.businessofapps.com/app-developers/entertainment/)
      - [Financial](https://www.businessofapps.com/app-developers/financial-fintech/)
      - [Games](https://www.businessofapps.com/app-developers/games/)
      - [Healthcare](https://www.businessofapps.com/app-developers/healthcare/)
      - [Logistics](https://www.businessofapps.com/app-developers/logistics)
      - [Real Estate](https://www.businessofapps.com/app-developers/real-estate/)
      - [Restaurant](https://www.businessofapps.com/app-developers/restaurant/)
      - [Social](https://www.businessofapps.com/app-developers/#directory)
      - [Startup](https://www.businessofapps.com/app-developers/#directory)
      - [Travel](https://www.businessofapps.com/app-developers/#directory)
      - [Browse all Verticals](https://www.businessofapps.com/app-developers/#directory)
    - [App Builders](https://www.businessofapps.com/marketplace/app-builders/)
  - [Affiliate](https://www.businessofapps.com/affiliate/)
    - [Affiliate Marketing](https://www.businessofapps.com/affiliate/#directory)
      - [Networks](https://www.businessofapps.com/affiliate/networks/)
      - [Programs](https://www.businessofapps.com/affiliate/programs/)
      - [Mobile CPA](https://www.businessofapps.com/affiliate/mobile-cpa/)
      - [Mobile Games](https://www.businessofapps.com/affiliate/mobile-games/)
    - [Offer Types](https://www.businessofapps.com/affiliate/#directory)
      - [Apps](https://www.businessofapps.com/affiliate/apps/)
      - [Betting](https://www.businessofapps.com/affiliate/betting/)
      - [Casino](https://www.businessofapps.com/affiliate/casino/)
      - [CBD](https://www.businessofapps.com/affiliate/cbd/)
      - [Coupons](https://www.businessofapps.com/affiliate/coupons/)
      - [Crypto](https://www.businessofapps.com/affiliate/crypto/)
      - [Dating](https://www.businessofapps.com/affiliate/dating/)
      - [Ecommerce](https://www.businessofapps.com/affiliate/ecommerce/)
      - [Entertainment](https://www.businessofapps.com/affiliate/entertainment/)
      - [Esports](https://www.businessofapps.com/affiliate/esports/)
      - [Gambling](https://www.businessofapps.com/affiliate/gambling/)
      - [Games](https://www.businessofapps.com/affiliate/games/)
      - [Health](https://www.businessofapps.com/affiliate/health/)
      - [Lead Generation](https://www.businessofapps.com/affiliate/lead-generation/)
      - [Nutra](https://www.businessofapps.com/affiliate/nutra/)
      - [Pay Per Call](https://www.businessofapps.com/affiliate/pay-per-call/)
      - [Pin Submit](https://www.businessofapps.com/affiliate/pin-submit/)
      - [Poker](https://www.businessofapps.com/affiliate/poker/)
      - [Social](https://www.businessofapps.com/affiliate/social/)
      - [Software](https://www.businessofapps.com/affiliate/software/)
      - [Sweepstakes](https://www.businessofapps.com/affiliate/sweepstakes/)
      - [Travel](https://www.businessofapps.com/affiliate/travel/)
      - [Utilities](https://www.businessofapps.com/affiliate/utilities/)
      - [Browse all Offer Types](https://www.businessofapps.com/affiliate/#directory)
    - [Commission Types](https://www.businessofapps.com/affiliate/#directory)
      - [CPA](https://www.businessofapps.com/affiliate/cpa/)
      - [CPC](https://www.businessofapps.com/affiliate/cpc/)
      - [CPI](https://www.businessofapps.com/affiliate/cpi/)
      - [CPL](https://www.businessofapps.com/affiliate/cpl/)
      - [CPM](https://www.businessofapps.com/affiliate/cpm/)
      - [CPS](https://www.businessofapps.com/affiliate/cps/)
      - [RevShare](https://www.businessofapps.com/affiliate/revshare/)
- [Events](https://www.businessofapps.com/events/)
  - [BOA NYC – Sept 2026](https://www.businessofapps.com/event/nyc/)
  - [BOA Berlin – Nov 2026](https://www.businessofapps.com/event/berlin/)
  - [BOA London – Apr 2027](https://www.businessofapps.com/event/london/)
  - [Online Events](https://www.businessofapps.com/webinars)

[Subscribe](https://www.businessofapps.com/register) [Advertise](https://www.businessofapps.com/advertise/)

[![](https://www.businessofapps.com/wp-content/themes/boa/lib/assets/images/logo-boa-new.svg)](https://www.businessofapps.com/)

- [Channels](https://www.businessofapps.com/data/app-retention-rates/#)
  - [Inside App Scalingby Mintegral](https://www.businessofapps.com/channels/inside-app-scaling/)
  - [TVby Tatari](https://www.businessofapps.com/channels/tv/)
  - [Mobile Growthby Verve](https://www.businessofapps.com/channels/mobile-growth/)
  - [How I Grew Thisby Branch](https://www.businessofapps.com/channels/how-i-grew-this/)
  - [App Developmentby Designli](https://www.businessofapps.com/channels/app-development/)
  - [Web Monetizationby Paddle](https://www.businessofapps.com/channels/web-monetization/)
  - [Women in Mobileby Liftoff](https://www.businessofapps.com/channels/women-in-mobile/)
- [Media](https://www.businessofapps.com/data/app-retention-rates/#)
  - [Insights](https://www.businessofapps.com/insights/)
  - [Interviews](https://www.businessofapps.com/video/app-talks/)
  - [Video](https://www.businessofapps.com/video/)
  - [Podcast](https://www.businessofapps.com/podcasts/)
  - [Resources](https://www.businessofapps.com/resources/)
  - [Downloads](https://www.businessofapps.com/downloads/)
  - [App Leaders](https://www.businessofapps.com/app-leaders/)
  - [Guides](https://www.businessofapps.com/guides/)
  - [News](https://www.businessofapps.com/news)
- [Data](https://www.businessofapps.com/data/)
  - [App Benchmarks](https://www.businessofapps.com/data/app-benchmarks/)
  - [App Reports](https://www.businessofapps.com/data/app-reports/)
  - [App Market](https://www.businessofapps.com/data/app-market/)
  - [App Sectors](https://www.businessofapps.com/data/app-sectors/)
  - [App Stats](https://www.businessofapps.com/data/app-data/)
  - [App Rankings](https://www.businessofapps.com/data/app-rankings/)
- [Marketplace](https://www.businessofapps.com/marketplace/)
  - [App Marketing](https://www.businessofapps.com/marketplace/app-marketing/)
    - [AI Marketing](https://www.businessofapps.com/marketplace/ai-marketing/)
    - [Growth Marketing](https://www.businessofapps.com/marketplace/growth-marketing/)
    - [Mobile Marketing](https://www.businessofapps.com/marketplace/mobile-marketing/)
    - [Mobile Game Marketing](https://www.businessofapps.com/marketplace/mobile-game-marketing/)
    - [Performance Marketing](https://www.businessofapps.com/marketplace/performance-marketing/)
  - [User Acquisition](https://www.businessofapps.com/marketplace/user-acquisition/)
    - [eCommerce UA](https://www.businessofapps.com/marketplace/user-acquisition/ecommerce/)
    - [Games UA](https://www.businessofapps.com/marketplace/user-acquisition/games/)
    - [Demand Side Platforms](https://www.businessofapps.com/ads/mobile-dsp/)
    - [Influencer Marketing](https://www.businessofapps.com/marketplace/influencer-marketing/)
      - [Influencer Marketing Platforms](https://www.businessofapps.com/marketplace/influencer-marketing/platforms/)
      - [Influencer Marketing Agencies](https://www.businessofapps.com/marketplace/influencer-marketing/agencies/)
      - [Social Media Marketing](https://www.businessofapps.com/marketplace/social-media-marketing/)
      - [TikTok Marketing](https://www.businessofapps.com/marketplace/tiktok/)
    - [App Installs](https://www.businessofapps.com/ads/app-installs)
    - [Apple Search Ads](https://www.businessofapps.com/marketplace/apple-search-ads)
    - [Retargeting](https://www.businessofapps.com/ads/retargeting))
    - [CTV Ads](https://www.businessofapps.com/ads/ctv)
    - [OEM Advertising](https://www.businessofapps.com/marketplace/oem-advertising)
  - [App Store Optimization](https://www.businessofapps.com/marketplace/app-store-optimization/)
    - [ASO Tools](https://www.businessofapps.com/marketplace/app-store-optimization/aso-tools/)
    - [Apple Search Ads](https://www.businessofapps.com/marketplace/apple-search-ads/)
    - [App Conversion Rate Optimization](https://www.businessofapps.com/marketplace/app-conversion-rate-optimization)
  - [App Engagement](https://www.businessofapps.com/marketplace/app-engagement/)
    - [Marketing Automation](https://www.businessofapps.com/marketplace/marketing-automation/)
    - [Mobile CRM](https://www.businessofapps.com/marketplace/mobile-crm)
    - [In-app Messaging](https://www.businessofapps.com/marketplace/in-app-messaging/)
    - [Push Notifications](https://www.businessofapps.com/marketplace/push-notifications/)
  - [App Analytics](https://www.businessofapps.com/marketplace/app-analytics/)
    - [Mobile Attribution](https://www.businessofapps.com/marketplace/mobile-attribution/)
    - [Mobile Measurement Partners](https://www.businessofapps.com/marketplace/app-analytics/mobile-measurement-partners/)
    - [Crash Reporting](https://www.businessofapps.com/marketplace/crash-reporting/)
    - [App Monitoring](https://www.businessofapps.com/marketplace/application-monitoring/)
    - [A/B Testing](https://www.businessofapps.com/marketplace/app-analytics/ab-testing)
  - [App Monetization](https://www.businessofapps.com/marketplace/app-monetization/)
    - [Ad Servers](https://www.businessofapps.com/ads/ad-servers/)
    - [Mobile Game Monetization](https://www.businessofapps.com/marketplace/game-monetization)
    - [Subscription Platforms](https://www.businessofapps.com/marketplace/subscription)
    - [Paywall Platforms](https://www.businessofapps.com/marketplace/paywall)
    - [App Investors](https://www.businessofapps.com/marketplace/app-investors/)
  - [Mobile Advertising](https://www.businessofapps.com/ads/)
    - [Categories](https://www.businessofapps.com/ads/#directory)
      - [Mobile Ad Networks](https://www.businessofapps.com/ads/mobile-ad-network/)
      - [Ad Networks](https://www.businessofapps.com/ads/ad-networks/)
      - [CTV Advertising](https://www.businessofapps.com/ads/ctv-advertising/)
      - [Ad Fraud Tools](https://www.businessofapps.com/ads/ad-fraud/)
      - [Ad Servers](https://www.businessofapps.com/ads/ad-servers/)
      - [Mobile DSPs](https://www.businessofapps.com/ads/mobile-dsp/)
      - [Retargeting](https://www.businessofapps.com/ads/retargeting/)
    - [Ad Formats](https://www.businessofapps.com/ads/#directory)
      - [Content Lock](https://www.businessofapps.com/ads/content-lock/)
      - [In-App](https://www.businessofapps.com/ads/in-app/)
      - [Popunder](https://www.businessofapps.com/ads/popunder/)
      - [Rewarded Video](https://www.businessofapps.com/ads/rewarded-video/)
    - [Video](https://www.businessofapps.com/ads/video/)
    - [Models](https://www.businessofapps.com/ads/#directory)
      - [CPI](https://www.businessofapps.com/ads/cpi/)
      - [CPM](https://www.businessofapps.com/ads/cpm/)
      - [CPC](https://www.businessofapps.com/ads/cpc/)
      - [CTV](https://www.businessofapps.com/ads/ctv/)
  - [App Developers](https://www.businessofapps.com/app-developers/)
    - [Platforms](https://www.businessofapps.com/app-developers/#directory)
      - [AI](https://www.businessofapps.com/app-developers/artificial-intelligence/)
      - [Android](https://www.businessofapps.com/app-developers/android/)
      - [Augmented Reality](https://www.businessofapps.com/app-developers/augmented-reality/)
      - [Blockchain](https://www.businessofapps.com/app-developers/blockchain-developers/)
      - [Freelance](https://www.businessofapps.com/app-developers/freelance/)
      - [HTML5](https://www.businessofapps.com/app-developers/html5/)
      - [iOS](https://www.businessofapps.com/app-developers/ios/)
      - [IoT](https://www.businessofapps.com/app-developers/iot-developers/)
      - [Mobile Web](https://www.businessofapps.com/app-developers/mobile-web/)
      - [NFT](https://www.businessofapps.com/app-developers/nft-developers/)
      - [Web3](https://www.businessofapps.com/app-developers/web3-developers/)
      - [Browse all Platforms](https://www.businessofapps.com/app-developers/#directory)
    - [Countries](https://www.businessofapps.com/app-developers/#directory)
      - [Australia](https://www.businessofapps.com/app-developers/australia/)
      - [Canada](https://www.businessofapps.com/app-developers/canada/)
      - [India](https://www.businessofapps.com/app-developers/india/)
      - [UK](https://www.businessofapps.com/app-developers/uk/)
      - [USA](https://www.businessofapps.com/app-developers/usa/)
    - [Cities](https://www.businessofapps.com/app-developers/#directory)
      - [London](https://www.businessofapps.com/app-developers/london/)
      - [Los Angeles](https://www.businessofapps.com/app-developers/los-angeles/)
      - [Manchester](https://www.businessofapps.com/app-developers/manchester/)
      - [Miami](https://www.businessofapps.com/app-developers/miami/)
      - [New York](https://www.businessofapps.com/app-developers/nyc/)
      - [San Francisco](https://www.businessofapps.com/app-developers/san-francisco/)
      - [Toronto](https://www.businessofapps.com/app-developers/toronto/)
    - [Verticals](https://www.businessofapps.com/app-developers/#directory)
      - [Ecommerce](https://www.businessofapps.com/app-developers/ecommerce/)
      - [Education](https://www.businessofapps.com/app-developers/education/)
      - [Enterprise](https://www.businessofapps.com/app-developers/enterprise/)
      - [Entertainment](https://www.businessofapps.com/app-developers/entertainment/)
      - [Financial](https://www.businessofapps.com/app-developers/financial-fintech/)
      - [Games](https://www.businessofapps.com/app-developers/games/)
      - [Healthcare](https://www.businessofapps.com/app-developers/healthcare/)
      - [Logistics](https://www.businessofapps.com/app-developers/logistics)
      - [Real Estate](https://www.businessofapps.com/app-developers/real-estate/)
      - [Restaurant](https://www.businessofapps.com/app-developers/restaurant/)
      - [Social](https://www.businessofapps.com/app-developers/#directory)
      - [Startup](https://www.businessofapps.com/app-developers/#directory)
      - [Travel](https://www.businessofapps.com/app-developers/#directory)
      - [Browse all Verticals](https://www.businessofapps.com/app-developers/#directory)
    - [App Builders](https://www.businessofapps.com/marketplace/app-builders/)
  - [Affiliate](https://www.businessofapps.com/affiliate/)
    - [Affiliate Marketing](https://www.businessofapps.com/affiliate/#directory)
      - [Networks](https://www.businessofapps.com/affiliate/networks/)
      - [Programs](https://www.businessofapps.com/affiliate/programs/)
      - [Mobile CPA](https://www.businessofapps.com/affiliate/mobile-cpa/)
      - [Mobile Games](https://www.businessofapps.com/affiliate/mobile-games/)
    - [Offer Types](https://www.businessofapps.com/affiliate/#directory)
      - [Apps](https://www.businessofapps.com/affiliate/apps/)
      - [Betting](https://www.businessofapps.com/affiliate/betting/)
      - [Casino](https://www.businessofapps.com/affiliate/casino/)
      - [CBD](https://www.businessofapps.com/affiliate/cbd/)
      - [Coupons](https://www.businessofapps.com/affiliate/coupons/)
      - [Crypto](https://www.businessofapps.com/affiliate/crypto/)
      - [Dating](https://www.businessofapps.com/affiliate/dating/)
      - [Ecommerce](https://www.businessofapps.com/affiliate/ecommerce/)
      - [Entertainment](https://www.businessofapps.com/affiliate/entertainment/)
      - [Esports](https://www.businessofapps.com/affiliate/esports/)
      - [Gambling](https://www.businessofapps.com/affiliate/gambling/)
      - [Games](https://www.businessofapps.com/affiliate/games/)
      - [Health](https://www.businessofapps.com/affiliate/health/)
      - [Lead Generation](https://www.businessofapps.com/affiliate/lead-generation/)
      - [Nutra](https://www.businessofapps.com/affiliate/nutra/)
      - [Pay Per Call](https://www.businessofapps.com/affiliate/pay-per-call/)
      - [Pin Submit](https://www.businessofapps.com/affiliate/pin-submit/)
      - [Poker](https://www.businessofapps.com/affiliate/poker/)
      - [Social](https://www.businessofapps.com/affiliate/social/)
      - [Software](https://www.businessofapps.com/affiliate/software/)
      - [Sweepstakes](https://www.businessofapps.com/affiliate/sweepstakes/)
      - [Travel](https://www.businessofapps.com/affiliate/travel/)
      - [Utilities](https://www.businessofapps.com/affiliate/utilities/)
      - [Browse all Offer Types](https://www.businessofapps.com/affiliate/#directory)
    - [Commission Types](https://www.businessofapps.com/affiliate/#directory)
      - [CPA](https://www.businessofapps.com/affiliate/cpa/)
      - [CPC](https://www.businessofapps.com/affiliate/cpc/)
      - [CPI](https://www.businessofapps.com/affiliate/cpi/)
      - [CPL](https://www.businessofapps.com/affiliate/cpl/)
      - [CPM](https://www.businessofapps.com/affiliate/cpm/)
      - [CPS](https://www.businessofapps.com/affiliate/cps/)
      - [RevShare](https://www.businessofapps.com/affiliate/revshare/)
- [Events](https://www.businessofapps.com/events/)
  - [BOA NYC – Sept 2026](https://www.businessofapps.com/event/nyc/)
  - [BOA Berlin – Nov 2026](https://www.businessofapps.com/event/berlin/)
  - [BOA London – Apr 2027](https://www.businessofapps.com/event/london/)
  - [Online Events](https://www.businessofapps.com/webinars)

[Subscribe](https://www.businessofapps.com/register) [Advertise](https://www.businessofapps.com/advertise/)

[Join / Login](https://www.businessofapps.com/signup/membership/)

[Menu](https://www.businessofapps.com/data/app-retention-rates/#sidr)

[![](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E)](https://www.businessofapps.com/data/app-retention-rates/#)

- [Home](https://www.businessofapps.com/)
- [App Data](https://www.businessofapps.com/data/)
- App Retention Rates (2026)

# App Retention Rates (2026)

![](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2035%2035'%3E%3C/svg%3E)

[David Curry](https://www.businessofapps.com/news/author/david-curry/)

Updated: July 14, 2026

[Share this page on LinkedIn](https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.businessofapps.com%2Fdata%2Fapp-retention-rates "Share this page on LinkedIn")[Share this page on Twitter](https://twitter.com/intent/tweet?text=App+Retention+Rates+%282026%29&url=https%3A%2F%2Fwww.businessofapps.com%2Fdata%2Fapp-retention-rates&via=@BusinessofApps "Share this page on Twitter")[Share this page through email](mailto:?subject=App+Retention+Rates+%282026%29 "Share this page through email")

Share:

##### App Retention Rates (2026) - Business of Apps

![](https://www.businessofapps.com/wp-content/uploads/2022/11/retention.png)

Copied to clipboard

##### Content Menu

- [Key App Retention Statistics](https://www.businessofapps.com/data/app-retention-rates/#KeyAppRetentionStatistics)
- [iOS App Retention Rate](https://www.businessofapps.com/data/app-retention-rates/#iOSAppRetentionRate_1)
- [Android App Retention Rate](https://www.businessofapps.com/data/app-retention-rates/#AndroidAppRetentionRate_1)
- [iOS Retention Rate by Category](https://www.businessofapps.com/data/app-retention-rates/#iOSRetentionRatebyCategory_1)
- [Android Retention Rate by Category](https://www.businessofapps.com/data/app-retention-rates/#AndroidRetentionRatebyCategory_1)
- [App Retention Rate by Category](https://www.businessofapps.com/data/app-retention-rates/#AppRetentionRatebyCategory_1)
- [App Retention Rate by Country](https://www.businessofapps.com/data/app-retention-rates/#AppRetentionRatebyCountry_1)
- [App Subscription Retention Rate](https://www.businessofapps.com/data/app-retention-rates/#AppSubscriptionRetentionRate_3)
- [App Subscription Retention Rate by Category](https://www.businessofapps.com/data/app-retention-rates/#AppSubscriptionRetentionRatebyCategory_1)
- [App Subscription Retention Rate by Region](https://www.businessofapps.com/data/app-retention-rates/#AppSubscriptionRetentionRatebyRegion_1)

App retention is one of the most important metrics app marketers use to quantify an app's success rate, and whether attempts to keep a user active have worked.

With the vast majority of apps being free to download, retaining a user can be difficult, as they have invested very little into the app. App developers have many tricks to keep users returning, from in-app notifications to incentives for remaining active.

However, app retention rates across the board are low, with more than 90 percent of users giving up on an app before the 30 day mark. There are outliers, the most popular apps and games tend to be more sticky than the average, but even very popular mobile games see churn of more than 80 percent.

There are tons of guides out there with tips to improve retention rate, [including our own](https://www.businessofapps.com/guide/mobile-app-retention/), but negotiating with a user remains tricky, especially in the early stages. Some app marketers err on the side of taking a step back and letting the user find their own path, while others think every detail of onboarding should be measured and weight up to reach a better retention rate.

The journey is not over once a user has gets over the 30 day mark, with app marketers then focused on [converting users](https://www.businessofapps.com/data/app-conversion-rates/). This involves moving a user from passive to active, or free to paid. Even when a user has paid for a subscription, there is still a high percentage that become inactive and uninstall the app after a few weeks.

We have collected data and statistics on app retention rates. Read on below to find out more.

## Key App Retention Statistics

- The average iOS app retention rate was 25.4% on day one, dropping to 5.3% by day 30 ( [AppsFlyer](https://www.appsflyer.com/benchmarks/))
- The average Android app retention rate was lower, at 20.2% on day one and 3.8% by day 30
- News & magazine apps have some of the highest app retention rates, while generative AI and photo & video have the lowest
- RPG and sports games have the highest game retention rates on iOS, while puzzle and RPG are at the top on Android
- Japan has the highest average app retention rate by country, India has the lowest
- Just over 25% of annual subscribers are still active after one year. For monthly subs, only 7.6% of users are still active ( [RevenueCat](https://www.revenuecat.com/state-of-subscription-apps/))
- Business apps have the best annual subscription retention rate, education has the lowest
- Eastern Europe has the highest average subscription retention rate, India and SEA have the lowest

## iOS App Retention Rate

## Android App Retention Rate

## iOS Retention Rate by Category

## Android Retention Rate by Category

## App Retention Rate by Category

## App Retention Rate by Country

## App Subscription Retention Rate

## App Subscription Retention Rate by Category

## App Subscription Retention Rate by Region

To access this content please [sign up](https://www.businessofapps.com/signup/free-membership) to Business of Apps. Or login below if you are already a member.

Username or E-mail

Password

Remember Me

[Forgot Password](https://www.businessofapps.com/login/?action=forgot_password)

[![](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E)](https://www.businessofapps.com/event/nyc)

### Connecting the App Industry

Marketplace \| News & Insights \| Data \| Events

[LinkedIn](https://www.linkedin.com/company/businessofapps/ "LinkedIn")

[YouTube](https://www.youtube.com/channel/UCg2NMpWp3jI3zYg_R4NZIaQ?sub_confirmation=1 "YouTube")

[Instagram](https://www.instagram.com/businessofappshq/ "Instagram")

[7,183Trees plantedwith Treeapp](https://www.thetreeapp.org/impact/app-promotion-summit?utm_source=tree_counter_widget&utm_medium=widget&utm_id=tree_counter_widget&utm_campaign=tree+counter+widget)

Our Events

- [Berlin](https://apppromotionsummit.com/berlin/)
- [New York](https://apppromotionsummit.com/nyc/)
- [London](https://apppromotionsummit.com/london/)

Media

- [Insights](https://www.businessofapps.com/insights)
- [Video](https://www.businessofapps.com/video)
- [Interviews](https://www.businessofapps.com/video/app-talk-interviews/)
- [Podcasts](https://www.businessofapps.com/podcasts)
- [Guides](https://www.businessofapps.com/guides)
- [App Leaders](https://www.businessofapps.com/app-leaders/)
- [Downloads](https://www.businessofapps.com/downloads)
- [News](https://www.businessofapps.com/news)

Marketplace

- [App Marketing](https://www.businessofapps.com/marketplace/app-marketing/)
- [User Acquisition](https://www.businessofapps.com/marketplace/user-acquisition/)
- [App Developers](https://www.businessofapps.com/app-developers)
- [App Engagement](https://www.businessofapps.com/marketplace/app-engagement)
- [App Analytics](https://www.businessofapps.com/marketplace/app-analytics/)
- [App Monetization](https://www.businessofapps.com/marketplace/app-monetization/)
- [Mobile Advertising](https://www.businessofapps.com/ads)
- [Affiliate](https://www.businessofapps.com/affiliate)

App Data

- [Benchmarks](https://www.businessofapps.com/data/app-benchmarks/)
- [Reports](https://www.businessofapps.com/data/app-reports/)
- [Sectors](https://www.businessofapps.com/data/app-sectors/)
- [Stats](https://www.businessofapps.com/data/app-data/)
- [Rankings](https://www.businessofapps.com/data/app-rankings/)

Site Info

- [About Us](https://www.businessofapps.com/about/)
- [Partner with Business of Apps](https://www.businessofapps.com/advertise/)
- [Privacy Policy](https://www.businessofapps.com/privacy-policy/)
- [Contact Us](https://www.businessofapps.com/contact/)

![](https://www.businessofapps.com/wp-content/themes/boa/lib/assets/images/logo-boa-new.svg)

[Business of Apps Berlin Launch Tickets ending in](https://www.businessofapps.com/event/berlin/register/)

7

days

23

hours

25

minutes

0

seconds

[Get tickets.](https://www.businessofapps.com/data/event/berlin/register/)

[Business of Apps Berlin Launch Tickets ending 7th August](https://www.businessofapps.com/event/berlin/register/)

## Your weekly edge in app growth

Your competitors are already subscribed. Get the app news and intelligence that matters in one quick weekly read.

By signing up to receive our newsletter, you agree to our [privacy policy](https://www.businessofapps.com/privacy-policy/) You can opt out anytime.

![Newsletter-Image](https://143796548.hs-sites-eu1.com/hubfs/Newsletter-Image.png)

StripeM-Inner

Источник: https://www.businessofapps.com/data/app-retention-rates/ — снято 2026-07-31.
