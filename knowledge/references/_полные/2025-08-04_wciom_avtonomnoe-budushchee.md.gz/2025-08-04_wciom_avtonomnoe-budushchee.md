# Снимок источника

URL: https://wciom.ru/analytical-reviews/analiticheskii-obzor/kurs-na-avtonomnoe-budushchee
Снято: 2026-07-30
statusCode: 200

---

# Что хотите найти?

- **Клиентам**
  - [Преимущества](https://ok.wciom.ru/#advantages)
  - [Все решения](https://ok.wciom.ru/research)
  - [Консалтинг](https://consult.wciom.ru/)
  - [Коммуникации](https://ok.wciom.ru/research/communications)
  - [Кейсы](https://ok.wciom.ru/keisy)
  - [Контакты](https://ok.wciom.ru/contacts)
- **Исследователям**
  - [Грушинская конференция](https://conf.wciom.ru/)
  - [Научный совет](https://wciom.ru/o-kompanii/nauchnyi-sovet)
  - [Методлаборатория](https://profi.wciom.ru/metodlaboratorija/)
  - [Профразговор](https://wciom.ru/prof-conversation)
  - [Социологический диктант](https://dict.wciom.ru/)
- **Обучающимся**
  - [ВЦИОМ-Прометей](https://prometey.wciom.ru/)
  - [Стажировки](https://prometey.wciom.ru/interships)
  - [Дипломник года](https://prometey.wciom.ru/diplomnik-goda)
  - [Студент года](https://prometey.wciom.ru/student-goda)
  - [Социологический диктант](https://dict.wciom.ru/)
  - [Библиотека знаний](https://prometey.wciom.ru/biblioteka-znanii)
  - [Подкасты](https://music.yandex.ru/album/14508311?dir=desc&activeTab=about)
  - [Дни открытых дверей](https://prometey.wciom.ru/den-otkrytykh-dverei)
  - [Зимняя школа](https://prometey.wciom.ru/sociologicheskaja-shkola)
- **База данных**
  - [Архив знаний](https://profi.wciom.ru/arkhiv_znanii/)
  - [Результаты опросов «Спутник»](https://bd.wciom.ru/baza_rezultatov_sputnik/)
  - [Результаты опросов «Архивариус»](https://bd.wciom.ru/baza_rezultatov_oprosa_s_1992_goda/)
  - [База данных Roper Center](https://bd.wciom.ru/baza_dannykh_roper_center/)
  - [Электоральное прогнозирование](https://bd.wciom.ru/prognozy/)
- **Книги и Журнал**
  - [Книги авторов АЦ ВЦИОМ и российских ученых](https://book.wciom.ru/knigi/knigi_avtorov_vciom_i_rossijskih_uchenyh/)
  - [Журнал «Мониторинг»](https://www.monitoringjournal.ru/)
  - [Переводы зарубежной литературы](https://book.wciom.ru/knigi/knigi/)
- **О компании**
  - [История компании](https://wciom.ru/o-kompanii/istorija-vciom)
  - [О команде](https://wciom.ru/o-kompanii/o-komande)
  - [КСО](https://kso.wciom.ru/)
  - [Партнеры](https://wciom.ru/o-kompanii/partnery)
  - [Вопрос-ответ](https://wciom.ru/o-kompanii/vopros-otvet)
  - [Бином ВЦИОМ](https://wciom.ru/o-kompanii/faq-proekt-binom-vciom)
  - [Вакансии](https://wciom.ru/o-kompanii/vakansii/vakansii)

[Рейтинги](https://wciom.ru/ratings "Рейтинги") [Аналитические обзоры](https://wciom.ru/analytical-reviews "Аналитические обзоры") [Аналитические доклады](https://wciom.ru/analytical-reports "Аналитические доклады") [Презентации](https://wciom.ru/presentation "Презентации") [Инфографика](https://wciom.ru/infographics "Инфографика") [Книжная зависимость](https://wciom.ru/books-addiction "Книжная зависимость") [События](https://wciom.ru/announcement "События") [Экспертиза](https://wciom.ru/expertises "Экспертиза") [Прометей](https://prometey.wciom.ru/ "Прометей")

![](https://wciom.ru/fileadmin/_processed_/2/3/csm_TASS_813279051_ce8fa044ca.jpg)



Фото: Оксана Король/Бизнес Online/ТАСС




[Бизнес](https://wciom.ru/tematicheskii-katalog/business)

04 августа 2025

# Курс на автономное будущее

Россияне положительно оценивают развитие автономных технологий, воспринимая их как практичную и перспективную технологию, способную повысить безопасность, удобство и комфорт труда и жизни.

04
августа 2025

Фото:

Коротко о главном

- 95% осведомлены о развитии автономных технологий в России; 91% позитивно относятся к таким технологиям.
- Чаще всего россияне слышали о роботах-доставщиках (77%).
- 81% убеждены, разработка таких технологий поможет освободить людей от опасных работ.
- 48% россиян хотели бы прокатиться на автономном легковом автомобиле.

ОбзорКомментарииТаблицыМетодикаИнфографика
Презентация

Массив

## Коротко о главном:

- 95% осведомлены о развитии автономных технологий в России; 91% позитивно относятся к таким технологиям.
- Чаще всего россияне слышали о роботах-доставщиках (77%).
- 81% убеждены, разработка таких технологий поможет освободить людей от опасных работ.
- 48% россиян хотели бы прокатиться на автономном легковом автомобиле.

* * *

**МОСКВА, 4 августа 2025 г.** Аналитический центр ВЦИОМ представляет результаты опроса россиян об автономных технологиях.

|     |
| --- |
| **Вчера — фантастика, сегодня — реальность** |

Автономный транспорт активно переходит из сферы технологических экспериментов в повседневность. Абсолютное большинство россиян с разной степенью понимания осведомлены о разработке автономных технологий в России (95%). И **девять из десяти** **позитивно к ним относятся (91%).** При этом среди россиян, которые интересуются новостями о развитии технологий и разбираются в этой сфере, эта доля еще выше (по 95%).

В тех регионах, где автономные технологии уже испытываются на практике, **отношение к ним также остается доброжелательным**, а уровень негативных оценок минимален. Причем те, кто лично пользовался беспилотными автомобилями или роботами-доставщиками, относятся к таким технологиям заметно лучше, чем те, у кого такого опыта не было (96% против 62% и 94% против 62% соответственно).

|     |
| --- |
| **От доставщика до бульдозера** |

Россияне чаще всего **ассоциируют автономные технологии с тем, что уже становится частью повседневности** — роботами-доставщиками (77%) и беспилотными такси (69%). Эти форматы заметнее и ближе к обычной жизни, чем, например, автономные трамваи (25%) или строительная техника (18%). В регионах, где технологии уже тестируются, уровень информированности выше: там чаще упоминают даже менее заметные решения — от роботов-официантов (62% vs 48% среди россиян в целом) до беспилотных самосвалов или бульдозеров (33% vs 18%. Исследование подтверждает: чем ближе практика, тем шире образ и понимание того, что такое автономные технологии.

|     |
| --- |
| **В светлое автономное будущее** |

Для большинства россиян развитие автономных технологий **связано с освобождением человека от опасного (81%) или рутинного (60%) труда, увеличением скорости (69%) и эффективности (64%) производственных процессов**, а также повышением бытового комфорта (52%). Практически половина россиян считает автономные технологии перспективным направлением (49%), способным также повысить качество работ (46%). Иными словами, такие технологии видятся прагматично, как инструмент рационализации труда, быта и производства.

Абсолютное большинство россиян считают, что **российским ученым и разработчикам нужно продолжать развивать автономные технологии**(95%, в том числе 71% абсолютно в этом уверены, а среди интересующихся темой — 83%) **.**  Единодушие наблюдается также в вопросах **широкого внедрения** автономных легковых автомобилей, автономных грузовиков и роботов-доставщиков (74%, 65% и 83% соответственно оценивают такие идеи позитивно).

Россияне воспринимают автономный транспорт как **технологический драйвер**, способный повлиять не только на логистику, но и на более широкие сферы: от цифровых технологий, экологии и безопасности до социальной доступности. Среди **позитивных изменений, которые могут произойти благодаря широкому внедрению автономного транспорта** в повседневную жизнь, 44% россиян назвали развитие смежных технологий, таких как искусственный интеллект, сенсоры и связь, 37% — снижение стоимости доставки товаров, грузов, 30% — повышение мобильности людей с ограничениями в движении, которые сами не могут управлять транспортным средством.

**Интерес к автономным технологиям есть и на личном уровне:** 48% россиян и 31% среди жителей пилотных регионов хотели бы проехать на автономном легковом автомобиле, если бы была такая возможность; 59% и 31% соответственно хотели бы также получить заказ с помощью робота-доставщика.

|     |
| --- |
| **Яндекс, Tesla и КамАЗ** |

Большинство россиян знакомы с базовой информацией об автономном транспорте, особенно с тем, что касается **легковых автомобилей и роботов-доставщиков**. Однако конкретные факты о маршрутах, местах тестирования и статистике дорожно-транспортных происшествий известны меньшинству. Наиболее известные факты об автономном транспорте — это тестирование автономных автомобилей с 2022 года и роботов-доставщиков с 2019 года. Об этом знают по 70% россиян. Иными словами, в инфополе присутствует **общая картинка**, но **детали зачастую не доходят до широкой аудитории**.

Для большинства россиян рынок автономного транспорта ассоциируется с одной-двумя узнаваемыми компаниями — в первую очередь с **Яндекс (34%)**, а также с **Tesla** (12%) и **КамАЗ** (11%), еще 5% набирает Сбер. Почти половина опрошенных не смогла назвать ни одной компании, связанной с этой сферой.

**Автор:** Татьяна Смак

|  | ЦА 1 — население РФ |
| --- | --- |
| Хорошо об этом знаю, разбираюсь в данной теме | 19 |
| Слышал(а) об этом, но не разбираюсь в данной теме | 76 |
| Ничего не слышал(а) об этом ранее | 5 |

|  | ЦА 1 — население РФ | ЦА 2 — население регионов-пионеров, где автономный транспорт начал раньше тестироваться |
| --- | --- | --- |
| Позитивно | 55 | 54 |
| Скорее позитивно | 36 | 24 |
| Скорее негативно | 4 | 3 |
| Негативно | 1 | 4 |
| Безразлично, мне все равно | 3 | 11 |
| Затрудняюсь ответить | 1 | 4 |

|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | ЦА 1 — население РФ | Интерес к теме технологий | Осведомленность о развитии автономных технологий в России |
| Интересуюсь, слежу за новостями и достижениями в этой сфере | Специально не интересуюсь, только если случайно вижу в новостях | Не интересуюсь такими новостями | Хорошо об этом знаю, разбираюсь в данной теме | Слышал(а) об этом, но не разбираюсь в данной теме | Ничего не слышал(а) об этом ранее |
| Позитивно | 55 | 66 | 48 | 18 | 75 | 52 | 27 |
| Скорее позитивно | 36 | 29 | 41 | 23 | 20 | 40 | 28 |
| Скорее негативно | 4 | 3 | 5 | 14 | 4 | 4 | 5 |
| Негативно | 1 | 0 | 0 | 3 | 0 | 1 | 0 |
| Безразлично, мне все равно | 3 | 0 | 4 | 27 | 1 | 2 | 22 |
| Затрудняюсь ответить | 1 | 2 | 2 | 15 | 0 | 1 | 18 |

|  | ЦА 2 — население регионов-пионеров, где автономный транспорт начал раньше тестироваться | Есть личный опыт использования легковых автомобилей | нет такого опыта | Есть личный опыт использования роботов-доставщиков | нет такого опыта |
| --- | --- | --- | --- | --- | --- |
| Позитивно | 54 | 80 | 28 | 76 | 34 |
| Скорее позитивно | 24 | 16 | 34 | 18 | 28 |
| Скорее негативно | 3 | 0 | 3 | 1 | 4 |
| Негативно | 4 | 2 | 3 | 1 | 6 |
| Безразлично, мне все равно | 11 | 1 | 22 | 2 | 20 |
| Затрудняюсь ответить | 4 | 1 | 10 | 2 | 8 |

|  | ЦА 1 — население РФ | ЦА 2 — население регионов-пионеров, где автономный транспорт начал раньше тестироваться |
| --- | --- | --- |
| Роботы-доставщики | 77 | 82 |
| Автономные легковые автомобили, такси | 69 | 82 |
| Роботы в сфере промышленного производства | 59 | 57 |
| Автономная складская техника: роботы-погрузчики, сборщики | 53 | 53 |
| Роботы сферы обслуживания (робот-официант) | 48 | 62 |
| Автономные грузовики | 43 | 44 |
| Автономные трамваи | 25 | 26 |
| Автономная строительная техника: бульдозеры, экскаваторы, самосвалы | 18 | 33 |
| Слышал(а) в целом, но без подробностей | 3 | 0 |
| Другое | 5 | 1 |
| Вопрос не задавался (ничего не слышали о разработке автономных технологий в России) | 5 | 10 |

|  | ЦА 1 — население РФ |
| --- | --- |
| …поможет освободить людей от опасных работ | 81 |
| …увеличит скорость производственных/логистических процессов | 69 |
| …увеличит производительность труда | 64 |
| …позволит освободить людей от рутинных работ | 60 |
| …повысит уровень бытового комфорта | 52 |
| …перспективное направление | 49 |
| …позволит повысить качество работ | 46 |
| Другое | 3 |
| Затрудняюсь ответить | 0 |

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | ЦА 1 — население РФ | Интерес к теме технологий |
| Интересуюсь, слежу за новостями и достижениями в этой сфере | Специально не интересуюсь, только если случайно вижу в новостях | Не интересуюсь такими новостями |
| Определенно нужно | 71 | 83 | 64 | 18 |
| Скорее нужно | 24 | 14 | 30 | 35 |
| Скорее не нужно | 2 | 1 | 2 | 6 |
| Определенно не нужно | 0 | 1 | 0 | 8 |
| Затрудняюсь ответить | 3 | 1 | 4 | 33 |

|     |     |     |     |
| --- | --- | --- | --- |
|  | ЦА 1 — население РФ |
| автономных легковых автомобилей | автономных грузовиков | роботов-доставщиков |
| С интересом | 65 | 56 | 64 |
| С опасением | 35 | 37 | 8 |
| С ожиданием | 23 | 24 | 24 |
| С воодушевлением | 12 | 9 | 15 |
| С восторгом | 4 | 4 | 12 |
| С недоумением | 3 | 4 | 3 |
| С радостью | 3 | 5 | 15 |
| С грустью | 3 | 2 | 1 |
| Со злостью | 0 | 0 | 0 |
| Другое | 0 | 0 | 0 |
| Мне все равно | 2 | 4 | 6 |
| Затрудняюсь ответить | 1 | 1 | 1 |

|     |     |     |     |
| --- | --- | --- | --- |
|  | ЦА 1 — население РФ |
| автономных легковых автомобилей | автономных грузовиков | роботов-доставщиков |
| Позитивные | 74 | 65 | 83 |
| Нейтральные | 38 | 38 | 29 |
| Негативные | 25 | 28 | 11 |
| Другое | 0 | 0 | 0 |
| Затрудняюсь ответить | 1 | 2 | 1 |

|  | ЦА 1 — население РФ |
| --- | --- |
| Развитие смежных технологий, таких как искусственный интеллект, сенсоры и связь | 44 |
| Снижение стоимости доставки товаров, грузов | 37 |
| Повышение мобильности людей с ограничениями в движении, которые сами не могут управлять транспортным средством | 30 |
| Снижение остроты проблемы дефицита кадров в области доставки | 29 |
| Снижение уровня загрязнения воздуха в городах | 26 |
| Развитие интернет-торговли и сервисов доставки | 25 |
| Повышение безопасности дорожного движения | 22 |
| Повышение точности и предсказуемости перевозок | 21 |
| Снижение стоимости проезда транспорте | 15 |
| Уменьшение пробок на дорогах, трассах | 12 |
| Никакие / не будет позитивных изменений | 2 |
| Другое | 1 |
| Затрудняюсь ответить | 3 |

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
|  | проехать на автономном легковом автомобиле | получить заказ с помощью робота-доставщика |
|  | ЦА 1 — население РФ | ЦА 2 — население регионов-пионеров, где автономный транспорт начал раньше тестироваться | ЦА 1 — население РФ | ЦА 2 — население регионов-пионеров, где автономный транспорт начал раньше тестироваться |
| Хотел(а) бы | 48 | 31 | 59 | 31 |
| Не хотел(а) бы | 14 | 17 | 7 | 11 |
| Затрудняюсь ответить | 6 | 6 | 8 | 4 |
| Вопрос не задавался | 32 | 46 | 26 | 54 |

|     |     |     |     |
| --- | --- | --- | --- |
|  | ЦА 1 — население РФ |
|  | Встречал(а) эту информацию | Не встречал(а) эту информацию | Не помню /  затрудняюсь ответить |
| С 2022 года в России тестируют автономные автомобили | 70 | 19 | 11 |
| Роботы-доставщики тестируются в России с 2019 года | 70 | 20 | 10 |
| У автономного автомобиля есть полный обзор в 360 градусов и нет слепых зон — датчики позволяют контролировать ситуацию со всех сторон дороги | 66 | 25 | 9 |
| Электрические роботы-доставщики сокращают выбросы углерода, что делает их более экологически безопасными, в сравнении с автомобилями с двигателями внутреннего сгорания | 55 | 36 | 9 |
| С 2018 года в Иннополисе работают автономные такси | 38 | 48 | 14 |
| С 2023 года на трассе М-11 Санкт-Петербург — Москва автономные грузовики перевозят коммерческие грузы | 35 | 54 | 11 |
| На Центральной кольцевой автомобильной дороге в Московской области (ЦКАД) в 2025 году официально запустили автономное грузовое движение | 23 | 64 | 13 |
| За время тестирования автономных автомобилей было совершено 92 тыс. поездок и произошло 36 ДТП — из них только 2 по вине автономного транспорта | 19 | 68 | 13 |

|  | ЦА 1 — население РФ |
| --- | --- |
| Яндекс | 34 |
| Tesla | 12 |
| КамАЗ | 11 |
| Cбер | 5 |
| Ростех | 2 |
| Сколково | 2 |
| Google | 2 |
| Росатом | 1 |
| Старлайн | 1 |
| Иннополис | 1 |
| Cognitive Pilot | 1 |
| РЖД | 1 |
| Транспортные компании/линии (без уточнения) | 1 |
| НАМИ | 1 |
| АвтоВаз | 1 |
| МАДИ | 1 |
| Х5 Group | 1 |
| Никакие / не знаю о таких компаниях | 47 |
| Другое | 14 |
| Затрудняюсь ответить | 1 |

![](https://wciom.ru/fileadmin/user_upload/Ksenija_Tarakanovskaja_new.png)

Ксения Демина

Эксперт Аналитического центра ВЦИОМ

_«Автономные технологии – понятие, объединяющее беспилотные автомобили, роботов-доставщиков и другие виды транспорта, способные выполнять свои задачи без непосредственного участия человека. Автономность техники – один из непременных элементов широко распространенного образа высокотехнологичного будущего, которое постепенно становится нашим настоящим. Россияне рассматривают его преимущественно прагматически – как возможность избавления от рутинных, но необходимых занятий и опасных видов работ. И многие готовы попробовать. А значит, востребованными становятся экспериментальные режимы и специальные опытные зоны, в которых люди будут тестировать новые технологии и учиться сосуществовать с ними в общем пространстве. Результатом станет лучшее понимание рисков и достоинств автономных технологий, качественная отработка проблемных кейсов, совершенствование конструкции автономных средств. И параллельно, уверена, будут развеяны многие беспочвенные страхи относительно автономной техники, что поможет ей быстрее прийти в нашу повседневную жизнь»._

**_[Перейти к странице эксперта](https://ok.wciom.ru/staff/profile/ksenija-tarakanovskaja)_**

* * *

04 августа 2025

- [Массив данных](https://wciom.ru/fileadmin/user_upload/massiv_50016.zip "Массив данных")


18-29 июня 2025 г.

_ЦА 1: всероссийский интернет-опрос «ВЦИОМ-Онлайн» / ЦА 2: комбинированный опрос: уличный опрос и интернет-опрос ВЦИОМ «ВЦИОМ-Онлайн»_

1629 / 502 опрошенныхЦА 1: в опросе приняли участие 1629 россиян в возрасте от 18 лет / ЦА 2: в опросе приняли участие 502 респондента в возрасте от 18 лет — население старше 18 лет регионов-пионеров, где автономный транспорт начал раньше тестироваться (р-н Ясенево г. Москвы (252 респондента), пгт Сириус (150 респондентов), г. Иннополис (100 респондентов).

_Метод опроса — интернет-опрос по формализованной анкете на базе вероятностной панели «ВЦИОМ-Онлайн». Участники панели рекрутируются в ходе ежедневного всероссийского телефонного (CATI) опроса «Спутник», который проводится по случайной (RDD) выборке мобильных номеров из полного списка телефонных номеров, задействованных на территории РФ._

_Данные всероссийского интернет-опроса взвешены по социально-демографическим параметрам. Для данной выборки предельная погрешность с вероятностью 95% не превышает 3,1%. Помимо погрешности выборки, смещение в данные опросов могут вносить формулировки вопросов и различные обстоятельства, возникающие в ходе полевых работ._

### Обращаем внимание

При использовании материалов сайта www.wciom.ru
или рассылки АЦ ВЦИОМ, ссылка на источник (или гиперссылка
для электронных изданий) обязательна.

### Остались вопросы?

Обращайтесь в пресс-службу, мы поможем
с данными и ответим на Ваши вопросы!

Контакты: +7 495 748 0807 #222; [press@wciom.com](mailto:press@wciom.com)

**Темы:**

[Бизнес](https://wciom.ru/tematicheskii-katalog/business) [Транспорт, логистика. Воздушный транспорт](https://wciom.ru/tematicheskii-katalog/transport-logistics-air-transport) [Наука](https://wciom.ru/tematicheskii-katalog/science) [Инновации](https://wciom.ru/tematicheskii-katalog/innovations) [Наука и техника](https://wciom.ru/tematicheskii-katalog/science-and-technology)

[Назад](https://wciom.ru/analytical-reviews)

Тематический каталог

Все категории

- [Политика](https://wciom.ru/tematicheskii-katalog/politics "Политика") 29






  - [Государственное, политическое устройство](https://wciom.ru/tematicheskii-katalog/state-and-political-structure "Государственное, политическое устройство")
  - [Институты государства и общества](https://wciom.ru/tematicheskii-katalog/state-and-society-institutions "Институты государства и общества")
  - [Политическая идеология](https://wciom.ru/tematicheskii-katalog/political-ideology "Политическая идеология")
  - [Патриотизм](https://wciom.ru/tematicheskii-katalog/patriotism "Патриотизм")
  - [Государственные символы](https://wciom.ru/tematicheskii-katalog/national-symbols "Государственные символы")
  - [Президент](https://wciom.ru/tematicheskii-katalog/president "Президент")
  - [Государственная Дума](https://wciom.ru/tematicheskii-katalog/state-duma "Государственная Дума")
  - [Политические партии](https://wciom.ru/tematicheskii-katalog/political-parties "Политические партии")
  - [Правительство РФ](https://wciom.ru/tematicheskii-katalog/government-of-the-russian-federation "Правительство РФ")
  - [Министерства](https://wciom.ru/tematicheskii-katalog/ministries "Министерства")
  - [Политики и государственные деятели](https://wciom.ru/tematicheskii-katalog/politicians-and-government-officials "Политики и государственные деятели")
  - [Общественные деятели](https://wciom.ru/tematicheskii-katalog/public-figures "Общественные деятели")
  - [Армия и оборона. Силовые структуры](https://wciom.ru/tematicheskii-katalog/army-and-defence-security-forces "Армия и оборона. Силовые структуры ")
  - [Национальная безопасность](https://wciom.ru/tematicheskii-katalog/national-security "Национальная безопасность")
  - [Политическая активность населения](https://wciom.ru/tematicheskii-katalog/populations-political-engagement "Политическая активность населения")
  - [Протестные настроения](https://wciom.ru/tematicheskii-katalog/protest-moods "Протестные настроения")
  - [Гражданские права и свободы](https://wciom.ru/tematicheskii-katalog/civil-rights-and-freedoms "Гражданские права и свободы")
  - [Политический экстремизм](https://wciom.ru/tematicheskii-katalog/political-extremism "Политический экстремизм")
  - [Фашизм](https://wciom.ru/tematicheskii-katalog/fascism "Фашизм")
  - [Терроризм](https://wciom.ru/tematicheskii-katalog/terrorism "Терроризм")
  - [Коррупция](https://wciom.ru/tematicheskii-katalog/corruption "Коррупция")
  - [Бюрократизм](https://wciom.ru/tematicheskii-katalog/bureaucracy "Бюрократизм")
  - [Административная реформа](https://wciom.ru/tematicheskii-katalog/administrative-reform "Административная реформа")
  - [Законодательство](https://wciom.ru/tematicheskii-katalog/legislation "Законодательство")
  - [Выборы](https://wciom.ru/tematicheskii-katalog/elections "Выборы")
  - [Электоральное прогнозирование](https://wciom.ru/tematicheskii-katalog/electoral-forecasting "Электоральное прогнозирование")
  - [Электоральные предпочтения и поведение](https://wciom.ru/tematicheskii-katalog/electoral-preferences-and-behavior "Электоральные предпочтения и поведение")
  - [«Горячие точки»](https://wciom.ru/tematicheskii-katalog/hot-spots "«Горячие точки»")
  - [Национальные проекты](https://wciom.ru/tematicheskii-katalog/national-projects "Национальные проекты")

- [Экономика](https://wciom.ru/tematicheskii-katalog/economy "Экономика") 7






  - [Экономическое положение](https://wciom.ru/tematicheskii-katalog/economic-situation "Экономическое положение")
  - [Реформы](https://wciom.ru/tematicheskii-katalog/reforms "Реформы")
  - [Недвижимость и строительство](https://wciom.ru/tematicheskii-katalog/real-estate-and-construction "Недвижимость и строительство")
  - [Потребительское поведение](https://wciom.ru/tematicheskii-katalog/consumer-behavior "Потребительское поведение")
  - [Энергетика, обеспечение электричеством, теплом, газом](https://wciom.ru/tematicheskii-katalog/energy-electricity-heat-gas "Энергетика, обеспечение электричеством, теплом, газом")
  - [Экспертиза продуктов, товаров, стандарты качества](https://wciom.ru/tematicheskii-katalog/products-and-goods-expertise "Экспертиза продуктов, товаров, стандарты качества")
  - [Бренды, товарные знаки, интеллектуальная собственность](https://wciom.ru/tematicheskii-katalog/brands-trademarks-intellectual-property "Бренды, товарные знаки, интеллектуальная собственность")

- [Финансы](https://wciom.ru/tematicheskii-katalog/finance "Финансы") 8






  - [Финансовое поведение](https://wciom.ru/tematicheskii-katalog/financial-behavior "Финансовое поведение")
  - [Банки и микрофинансовые организации](https://wciom.ru/tematicheskii-katalog/banks-microfinance-organizations "Банки и микрофинансовые организации")
  - [Страховые компании](https://wciom.ru/tematicheskii-katalog/ensurance-companies "Страховые компании")
  - [Покупки и кредиты](https://wciom.ru/tematicheskii-katalog/purchases-and-credits "Покупки и кредиты")
  - [Инфляция. Цены](https://wciom.ru/tematicheskii-katalog/inflation-prices "Инфляция. Цены")
  - [Рубль. Доллар. Курс](https://wciom.ru/tematicheskii-katalog/ruble-dollar-exchange-rate "Рубль. Доллар. Курс")
  - [Должники, штрафы](https://wciom.ru/tematicheskii-katalog/debtors-fines "Должники, штрафы")
  - [Налоги](https://wciom.ru/tematicheskii-katalog/taxes "Налоги")

- [Труд](https://wciom.ru/tematicheskii-katalog/labor "Труд") 5






  - [Рынок труда. Занятость и безработица](https://wciom.ru/tematicheskii-katalog/labor-market-employment-and-unemployment "Рынок труда. Занятость и безработица")
  - [Управление персоналом](https://wciom.ru/tematicheskii-katalog/human-resources-management "Управление персоналом")
  - [Защита трудовых прав](https://wciom.ru/tematicheskii-katalog/labor-rights-protection "Защита трудовых прав ")
  - [Профсоюзы. Забастовки](https://wciom.ru/tematicheskii-katalog/trade-unions-strikes "Профсоюзы. Забастовки")
  - [Профессии](https://wciom.ru/tematicheskii-katalog/occupations "Профессии")

- [Бизнес](https://wciom.ru/tematicheskii-katalog/business "Бизнес") 11






  - [Предпринимательство](https://wciom.ru/tematicheskii-katalog/enterpreneurship "Предпринимательство")
  - [Обрабатывающая промышленность](https://wciom.ru/tematicheskii-katalog/manufacturing-industry "Обрабатывающая промышленность")
  - [Автомобильный рынок](https://wciom.ru/tematicheskii-katalog/car-market "Автомобильный рынок")
  - [Телекоммуникации и связь](https://wciom.ru/tematicheskii-katalog/telecommunications "Телекоммуникации и связь")
  - [Топливно-энергетический комплекс](https://wciom.ru/tematicheskii-katalog/fuel-and-power-industry "Топливно-энергетический комплекс")
  - [Транспорт, логистика. Воздушный транспорт](https://wciom.ru/tematicheskii-katalog/transport-logistics-air-transport "Транспорт, логистика. Воздушный транспорт")
  - [Торговля](https://wciom.ru/tematicheskii-katalog/trade "Торговля")
  - [Лесное хозяйство](https://wciom.ru/tematicheskii-katalog/forestry "Лесное хозяйство")
  - [Сельское хозяйство и рыболовство](https://wciom.ru/tematicheskii-katalog/agriculture-and-fishing "Сельское хозяйство и рыболовство")
  - [Малый и средний бизнес](https://wciom.ru/tematicheskii-katalog/small-and-medium-business "Малый и средний бизнес")
  - [Крупный бизнес. Олигархи](https://wciom.ru/tematicheskii-katalog/large-business-oligarchs "Крупный бизнес. Олигархи")

- [Образование](https://wciom.ru/tematicheskii-katalog/education "Образование") 8






  - [Высшее образование. ВУЗы. Студенчество](https://wciom.ru/tematicheskii-katalog/higher-education-universities-students "Высшее образование. ВУЗы. Студенчество ")
  - [Среднее профессиональное образование](https://wciom.ru/tematicheskii-katalog/secondary-vocational-education "Среднее профессиональное образование")
  - [Среднее образование. Школа. ЕГЭ](https://wciom.ru/tematicheskii-katalog/secondary-education-school "Среднее образование. Школа. ЕГЭ")
  - [Воспитание детей](https://wciom.ru/tematicheskii-katalog/child-rearing "Воспитание детей")
  - [Учителя и педагоги](https://wciom.ru/tematicheskii-katalog/teachers-and-lecturers "Учителя и педагоги ")
  - [Дистанционное образование](https://wciom.ru/tematicheskii-katalog/remote-learning "Дистанционное образование")
  - [Выбор профессии](https://wciom.ru/tematicheskii-katalog/career-choice "Выбор профессии")
  - [Навыки и переобучение](https://wciom.ru/tematicheskii-katalog/skills-and-retraining "Навыки и переобучение")

- [Здравоохранение](https://wciom.ru/tematicheskii-katalog/public-health "Здравоохранение") 11






  - [Здоровье и ЗОЖ](https://wciom.ru/tematicheskii-katalog/health-and-healthy-lifestyle "Здоровье и ЗОЖ")
  - [Зависимости](https://wciom.ru/tematicheskii-katalog/addiction "Зависимости")
  - [Донорство](https://wciom.ru/tematicheskii-katalog/organ-donation "Донорство")
  - [Медицинское страхование](https://wciom.ru/tematicheskii-katalog/health-insurance%C2%A0 "Медицинское страхование")
  - [Питание, диеты, продукты питания](https://wciom.ru/tematicheskii-katalog/nutrition-diets-food "Питание, диеты, продукты питания")
  - [Заболевания](https://wciom.ru/tematicheskii-katalog/deseases "Заболевания")
  - [Профилактика и диспансеризация](https://wciom.ru/tematicheskii-katalog/disease-prevention-and-medical "Профилактика и диспансеризация")
  - [Лечение и самолечение](https://wciom.ru/tematicheskii-katalog/treatment-and-self-medication "Лечение и самолечение")
  - [Пациенты и врачи](https://wciom.ru/tematicheskii-katalog/patients-and-physicians "Пациенты и врачи")
  - [Вакцинация](https://wciom.ru/tematicheskii-katalog/vaccination "Вакцинация")
  - [Эстетическая медицина](https://wciom.ru/tematicheskii-katalog/aesthetic-medicine "Эстетическая медицина")

- [Общество](https://wciom.ru/tematicheskii-katalog/society "Общество") 19






  - [Социальная структура общества](https://wciom.ru/tematicheskii-katalog/social-structure "Социальная структура общества")
  - [Самооценка материального положения](https://wciom.ru/tematicheskii-katalog/financial-self-assessment "Самооценка материального положения")
  - [Социальные настроения, социальное самочувствие](https://wciom.ru/tematicheskii-katalog/social-moods-social-well-being "Социальные настроения, социальное самочувствие")
  - [Преступность](https://wciom.ru/tematicheskii-katalog/crime "Преступность")
  - [Угрозы и страхи](https://wciom.ru/tematicheskii-katalog/threats-and-fears "Угрозы и страхи")
  - [Проблемный фон](https://wciom.ru/tematicheskii-katalog/problem-background "Проблемный фон")
  - [Семья](https://wciom.ru/tematicheskii-katalog/family "Семья")
  - [Молодежь](https://wciom.ru/tematicheskii-katalog/youth "Молодежь")
  - [Старость](https://wciom.ru/tematicheskii-katalog/old-age "Старость")
  - [Инвалидность](https://wciom.ru/tematicheskii-katalog/disability "Инвалидность")
  - [Пол и гендер](https://wciom.ru/tematicheskii-katalog/sex-and-gender "Пол и гендер")
  - [Любовь и секс](https://wciom.ru/tematicheskii-katalog/love-and-sex "Любовь и секс")
  - [Трагедии и катастрофы](https://wciom.ru/tematicheskii-katalog/tragedies-and-disasters "Трагедии и катастрофы")
  - [Экология. Климат. Погода](https://wciom.ru/tematicheskii-katalog/environment-climate-weather "Экология. Климат. Погода")
  - [Отношение к животным](https://wciom.ru/tematicheskii-katalog/attitudes-towards-animals "Отношение к животным")
  - [Градостроительство, планирование городов, урбанистика](https://wciom.ru/tematicheskii-katalog/urban-construction-urban "Градостроительство, планирование городов, урбанистика")
  - [Азартные игры](https://wciom.ru/tematicheskii-katalog/gambling "Азартные игры")
  - [ЖКХ. Тарифы](https://wciom.ru/tematicheskii-katalog/housing-and-utilities "ЖКХ. Тарифы")
  - [Счастье](https://wciom.ru/tematicheskii-katalog/happiness "Счастье")

- [Социальная ответственность](https://wciom.ru/tematicheskii-katalog/social-responsibility "Социальная ответственность") 5






  - [Социальная защита. Льготы](https://wciom.ru/tematicheskii-katalog/social-protection-benefits "Социальная защита. Льготы")
  - [Благотворительность](https://wciom.ru/tematicheskii-katalog/charity "Благотворительность")
  - [Волонтерство](https://wciom.ru/tematicheskii-katalog/volunteering "Волонтерство ")
  - [Социальная ответственность бизнеса, ESG](https://wciom.ru/tematicheskii-katalog/social-responsibility-esg "Социальная ответственность бизнеса, ESG")
  - [PRO BONO](https://wciom.ru/tematicheskii-katalog/pro-bono "PRO BONO")

- [Демография и миграция](https://wciom.ru/tematicheskii-katalog/demography-and-migration "Демография и миграция") 4






  - [Рождаемость. Смертность](https://wciom.ru/tematicheskii-katalog/birth-rate-death-rate "Рождаемость. Смертность")
  - [Иммиграция. Приезжие](https://wciom.ru/tematicheskii-katalog/immigration-newcomers "Иммиграция. Приезжие")
  - [Межнациональные отношения](https://wciom.ru/tematicheskii-katalog/inter-ethnic-relatons "Межнациональные отношения")
  - [Эмиграция. Релокация](https://wciom.ru/tematicheskii-katalog/emigration-relocation "Эмиграция. Релокация ")

- [Культура](https://wciom.ru/tematicheskii-katalog/culture "Культура") 8






  - [Литература и искусство](https://wciom.ru/tematicheskii-katalog/literature-and-art "Литература и искусство")
  - [Традиции и обычаи](https://wciom.ru/tematicheskii-katalog/traditions-and-customs "Традиции и обычаи")
  - [Одежда. Мода. Стиль. Имидж](https://wciom.ru/tematicheskii-katalog/clothes-fashion-style-image "Одежда. Мода. Стиль. Имидж")
  - [Мораль и ценности](https://wciom.ru/tematicheskii-katalog/moral-and-values "Мораль и ценности")
  - [Взаимоотношения между людьми](https://wciom.ru/tematicheskii-katalog/interpersonal-communication "Взаимоотношения между людьми")
  - [Религиозность. Конфессии](https://wciom.ru/tematicheskii-katalog/religiosity-confessions "Религиозность. Конфессии ")
  - [Кино](https://wciom.ru/tematicheskii-katalog/movie "Кино")
  - [Язык и речь](https://wciom.ru/tematicheskii-katalog/language-and-speech "Язык и речь")

- [История](https://wciom.ru/tematicheskii-katalog/history "История") 4






  - [Историческая память](https://wciom.ru/tematicheskii-katalog/historical-memory "Историческая память")
  - [Оценки прошлого, ожидание от будущего](https://wciom.ru/tematicheskii-katalog/assessments-of-the-past-expectations "Оценки прошлого, ожидание от будущего")
  - [Важные исторические события](https://wciom.ru/tematicheskii-katalog/important-historical-events "Важные исторические события")
  - [Исторические деятели](https://wciom.ru/tematicheskii-katalog/historical-figures "Исторические деятели")

- [Медиа](https://wciom.ru/tematicheskii-katalog/media "Медиа") 7






  - [СМИ. Доверие. Цензура](https://wciom.ru/tematicheskii-katalog/mass-media-trust-censorship "СМИ. Доверие. Цензура")
  - [Мессенджеры](https://wciom.ru/tematicheskii-katalog/messengers "Мессенджеры")
  - [Интернет и соцсети](https://wciom.ru/tematicheskii-katalog/internet-and-social-media "Интернет и соцсети")
  - [Радио](https://wciom.ru/tematicheskii-katalog/radio "Радио")
  - [Печатная пресса](https://wciom.ru/tematicheskii-katalog/print-media "Печатная пресса")
  - [Телевидение](https://wciom.ru/tematicheskii-katalog/television "Телевидение")
  - [Маркетинг. Реклама. Коммуникации, PR](https://wciom.ru/tematicheskii-katalog/marketing-communication-pr "Маркетинг. Реклама. Коммуникации, PR")

- [Регионы России](https://wciom.ru/tematicheskii-katalog/russian-regions "Регионы России") 15






  - [Дальневосточный федеральный округ](https://wciom.ru/tematicheskii-katalog/far-eastern-federal-district "Дальневосточный федеральный округ")
  - [Северо-Кавказский федеральный округ](https://wciom.ru/tematicheskii-katalog/north-caucasus-federal-district "Северо-Кавказский федеральный округ")
  - [Уральский федеральный округ](https://wciom.ru/tematicheskii-katalog/ural-federal-district "Уральский федеральный округ")
  - [Приволжский федеральный округ](https://wciom.ru/tematicheskii-katalog/volga-federal-district "Приволжский федеральный округ")
  - [Центральный федеральный округ](https://wciom.ru/tematicheskii-katalog/central-federal-district "Центральный федеральный округ")
  - [Южный федеральный округ](https://wciom.ru/tematicheskii-katalog/southern-federal-district "Южный федеральный округ")
  - [Северо-Западный федеральный округ](https://wciom.ru/tematicheskii-katalog/northwestern-federal-district "Северо-Западный федеральный округ")
  - [Сибирский федеральный округ](https://wciom.ru/tematicheskii-katalog/siberian-federal-district "Сибирский федеральный округ")
  - [Крым](https://wciom.ru/tematicheskii-katalog/crimea "Крым")
  - [Калининград](https://wciom.ru/tematicheskii-katalog/kaliningrad "Калининград ")
  - [Курилы](https://wciom.ru/tematicheskii-katalog/kuril-islands "Курилы")
  - [Новые регионы](https://wciom.ru/tematicheskii-katalog/new-territories "Новые регионы")
  - [Социально-экономическое положение в регионах](https://wciom.ru/tematicheskii-katalog/social-and-economic-the-regions "Социально-экономическое положение в регионах")
  - [Губернаторы. Региональные лидеры](https://wciom.ru/tematicheskii-katalog/governors-regional-leaders "Губернаторы. Региональные лидеры")
  - [Федерализм. Региональная политика](https://wciom.ru/tematicheskii-katalog/federalism-regional-policy "Федерализм. Региональная политика")

- [СНГ](https://wciom.ru/tematicheskii-katalog/cis "СНГ") 7






  - [Центральная Азия](https://wciom.ru/tematicheskii-katalog/central-asia "Центральная Азия")
  - [Балтия](https://wciom.ru/tematicheskii-katalog/baltic-states "Балтия")
  - [Украина](https://wciom.ru/tematicheskii-katalog/ukraine "Украина")
  - [Белоруссия. Союзное государство России и Белоруссии](https://wciom.ru/tematicheskii-katalog/belarus "Белоруссия. Союзное государство России и Белоруссии")
  - [Закавказье](https://wciom.ru/tematicheskii-katalog/transcaucasus "Закавказье")
  - [Непризнанные государства](https://wciom.ru/tematicheskii-katalog/unrecognized-states "Непризнанные государства ")
  - [СНГ. ЕАЭС. ОДКБ. ШОС](https://wciom.ru/tematicheskii-katalog/cis-eurasian-collective-organization "СНГ. ЕАЭС. ОДКБ. ШОС")

- [Мир](https://wciom.ru/tematicheskii-katalog/world "Мир") 11






  - [Европа и ЕС](https://wciom.ru/tematicheskii-katalog/europe-and-eu "Европа и ЕС")
  - [Ближний Восток](https://wciom.ru/tematicheskii-katalog/middle-east "Ближний Восток")
  - [Восточная Азия](https://wciom.ru/tematicheskii-katalog/east-asia "Восточная Азия")
  - [США и Канада](https://wciom.ru/tematicheskii-katalog/usa-and-canada "США и Канада")
  - [Латинская Америка](https://wciom.ru/tematicheskii-katalog/latin-america "Латинская Америка")
  - [Арктика](https://wciom.ru/tematicheskii-katalog/arctic "Арктика")
  - [Санкции](https://wciom.ru/tematicheskii-katalog/sanctions "Санкции")
  - [Дружественные и недружественные страны](https://wciom.ru/tematicheskii-katalog/friendly-and-unfriendly-states "Дружественные и недружественные страны")
  - [НАТО. ООН. ВТО. БРИКС](https://wciom.ru/tematicheskii-katalog/nato-un-wto-brics "НАТО. ООН. ВТО. БРИКС")
  - [Россия в международных организациях](https://wciom.ru/tematicheskii-katalog/russia-in-international-organizations "Россия в международных организациях")
  - [Россия в мире. Внешняя политика РФ](https://wciom.ru/tematicheskii-katalog/russia-globally-russian-foreign-policy "Россия в мире. Внешняя политика РФ")

- [События и даты](https://wciom.ru/tematicheskii-katalog/events-and-days "События и даты") 70






  - [День борьбы со СПИДом](https://wciom.ru/tematicheskii-katalog/aids-day "День борьбы со СПИДом")
  - [День Государственного флага РФ](https://wciom.ru/tematicheskii-katalog/national-flag-day-in-russia "День Государственного флага РФ")
  - [30-летие ВЦИОМ](https://wciom.ru/tematicheskii-katalog/vcioms-30th-anniversary "30-летие ВЦИОМ")
  - [Новый год](https://wciom.ru/tematicheskii-katalog/new-years-day "Новый год")
  - [Рождество у католических христиан](https://wciom.ru/tematicheskii-katalog/catholic-christmas "Рождество у католических христиан")
  - [День энергетика в России](https://wciom.ru/tematicheskii-katalog/power-engineers-day-in-russia "День энергетика в России")
  - [День работника органов безопасности](https://wciom.ru/tematicheskii-katalog/security-agency-workers-day "День работника органов безопасности")
  - [День Конституции РФ](https://wciom.ru/tematicheskii-katalog/russias-constitution-day "День Конституции РФ")
  - [День матери в России](https://wciom.ru/tematicheskii-katalog/mothers-day-in-russia "День матери в России")
  - [Всемирный день домашних животных](https://wciom.ru/tematicheskii-katalog/international-pet-day "Всемирный день домашних животных ")
  - [День социолога в России](https://wciom.ru/tematicheskii-katalog/sociologist-day-in-russia "День социолога в России")
  - [День полиции](https://wciom.ru/tematicheskii-katalog/police-day "День полиции")
  - [Всемирный день качества](https://wciom.ru/tematicheskii-katalog/world-quality-day "Всемирный день качества")
  - [День народного единства](https://wciom.ru/tematicheskii-katalog/national-unity-day "День народного единства")
  - [Международный день вегана](https://wciom.ru/tematicheskii-katalog/world-vegan-day "Международный день вегана")
  - [Хэллоуин](https://wciom.ru/tematicheskii-katalog/halloween "Хэллоуин")
  - [День работников рекламы в России](https://wciom.ru/tematicheskii-katalog/day-of-advertising-workers-in-russia "День работников рекламы в России")
  - [Всемирный день учителя](https://wciom.ru/tematicheskii-katalog/world-teachers-day "Всемирный день учителя")
  - [Всемирный день животных](https://wciom.ru/tematicheskii-katalog/world-animal-day "Всемирный день животных")
  - [Всемирный день улыбки](https://wciom.ru/tematicheskii-katalog/world-smile-day "Всемирный день улыбки")
  - [Международный день музыки](https://wciom.ru/tematicheskii-katalog/international-music-day "Международный день музыки")
  - [Международный день пожилых людей](https://wciom.ru/tematicheskii-katalog/international-day-of-older-persons "Международный день пожилых людей")
  - [День финансиста в России](https://wciom.ru/tematicheskii-katalog/financiers-day-in-russia "День финансиста в России")
  - [День знаний](https://wciom.ru/tematicheskii-katalog/knowledge-day "День знаний")
  - [День строителя в России](https://wciom.ru/tematicheskii-katalog/builders-day-in-russia "День строителя в России")
  - [День семьи, любви и верности (День Петра и Февронии)](https://wciom.ru/tematicheskii-katalog/day-of-family-love-and-faithfulness "День семьи, любви и верности (День Петра и Февронии)")
  - [День ГИБДД МВД РФ (День ГАИ России)](https://wciom.ru/tematicheskii-katalog/day-of-traffic-police "День ГИБДД МВД РФ (День ГАИ России)")
  - [Всемирный день НЛО (день уфолога)](https://wciom.ru/tematicheskii-katalog/world-ufo-day "Всемирный день НЛО (день уфолога)")
  - [День молодежи в России](https://wciom.ru/tematicheskii-katalog/youth-day-in-russia "День молодежи в России")
  - [День памяти и скорби – день начала Великой Отечественной войны](https://wciom.ru/tematicheskii-katalog/day-of-remembrance-and-sorrow "День памяти и скорби – день начала Великой Отечественной войны")
  - [День медицинского работника в России](https://wciom.ru/tematicheskii-katalog/medical-workers-day-in-russia "День медицинского работника в России")
  - [День отца](https://wciom.ru/tematicheskii-katalog/fathers-day "День отца")
  - [День изобретателя и рационализатора в России](https://wciom.ru/tematicheskii-katalog/day-of-inventors-and-innovators-in-russia "День изобретателя и рационализатора в России")
  - [Международный день блогера](https://wciom.ru/tematicheskii-katalog/international-blogger-day "Международный день блогера")
  - [День России](https://wciom.ru/tematicheskii-katalog/russia-day "День России")
  - [Международный день друзей](https://wciom.ru/tematicheskii-katalog/international-friendship-day "Международный день друзей")
  - [Пушкинский день в России (День русского языка)](https://wciom.ru/tematicheskii-katalog/pushkin-day-in-russia "Пушкинский день в России (День русского языка)")
  - [Всемирный день окружающей среды (День эколога)](https://wciom.ru/tematicheskii-katalog/world-environment-day "Всемирный день окружающей среды (День эколога)")
  - [День защиты детей в России](https://wciom.ru/tematicheskii-katalog/child-protection-day-in-russia "День защиты детей в России")
  - [День библиотек в России](https://wciom.ru/tematicheskii-katalog/library-day-in-russia "День библиотек в России")
  - [День российского предпринимательства](https://wciom.ru/tematicheskii-katalog/russian-entrepreneurship-day "День российского предпринимательства")
  - [День славянской письменности и культуры](https://wciom.ru/tematicheskii-katalog/day-of-slavic-writing-and-culture "День славянской письменности и культуры")
  - [День полярника в России](https://wciom.ru/tematicheskii-katalog/polar-explorers-day "День полярника в России")
  - [День фрилансера в России](https://wciom.ru/tematicheskii-katalog/freelancers-day-in-russia "День фрилансера в России")
  - [Всероссийский день посадки леса](https://wciom.ru/tematicheskii-katalog/all-russian-day-of-forest-planting "Всероссийский день посадки леса")
  - [День Победы](https://wciom.ru/tematicheskii-katalog/victory-day "День Победы")
  - [День радио](https://wciom.ru/tematicheskii-katalog/radio-day "День радио")
  - [Праздник весны и труда](https://wciom.ru/tematicheskii-katalog/spring-and-labour-day "Праздник весны и труда")
  - [Пасха](https://wciom.ru/tematicheskii-katalog/easter "Пасха")
  - [День российского парламентаризма](https://wciom.ru/tematicheskii-katalog/day-of-russian-parliamentarism "День российского парламентаризма")
  - [День донора в России](https://wciom.ru/tematicheskii-katalog/donors-day-in-russia "День донора в России")
  - [День мецената и благотворителя в России](https://wciom.ru/tematicheskii-katalog/day-of-patron-and-philanthropist-in-russia "День мецената и благотворителя в России")
  - [День космонавтики](https://wciom.ru/tematicheskii-katalog/cosmonautics-day "День космонавтики")
  - [День Рунета](https://wciom.ru/tematicheskii-katalog/runet-day "День Рунета")
  - [День единения народов Белоруссии и России](https://wciom.ru/tematicheskii-katalog/day-of-unity-of-the-peoples-of-russia-and-belarus "День единения народов Белоруссии и России")
  - [День смеха](https://wciom.ru/tematicheskii-katalog/april-fools-day "День смеха")
  - [День работника культуры России](https://wciom.ru/tematicheskii-katalog/cultural-worker-day "День работника культуры России")
  - [Международный день счастья](https://wciom.ru/tematicheskii-katalog/international-day-of-happiness "Международный день счастья")
  - [Всемирный день защиты прав потребителя](https://wciom.ru/tematicheskii-katalog/world-consumer-rights-day "Всемирный день защиты прав потребителя")
  - [Международный женский день](https://wciom.ru/tematicheskii-katalog/international-womens-day "Международный женский день")
  - [День защитника отечества](https://wciom.ru/tematicheskii-katalog/defender-of-the-fatherland-day "День защитника отечества")
  - [День всех влюбленных (День святого Валентина)](https://wciom.ru/tematicheskii-katalog/st-valentines-day "День всех влюбленных (День святого Валентина)")
  - [День зимних видов спорта в России](https://wciom.ru/tematicheskii-katalog/winter-sports-day-in-russia "День зимних видов спорта в России")
  - [День гражданской авиации в России](https://wciom.ru/tematicheskii-katalog/civil-aviation-day-in-russia "День гражданской авиации в России")
  - [День российской науки](https://wciom.ru/tematicheskii-katalog/russian-science-day "День российской науки")
  - [Масленица](https://wciom.ru/tematicheskii-katalog/maslenitsa "Масленица")
  - [Международный день памяти жертв Холокоста](https://wciom.ru/tematicheskii-katalog/international-holocaust-day "Международный день памяти жертв Холокоста")
  - [День студентов (Татьянин день)](https://wciom.ru/tematicheskii-katalog/student-day "День студентов (Татьянин день)")
  - [День российской печати](https://wciom.ru/tematicheskii-katalog/russian-printing-industry-day "День российской печати")
  - [Рождество у православных христиан](https://wciom.ru/tematicheskii-katalog/orthodox-christmas "Рождество у православных христиан")

- [Новости АЦ ВЦИОМ](https://wciom.ru/tematicheskii-katalog/vciom-news "Новости АЦ ВЦИОМ") 5






  - [Презентации исследований](https://wciom.ru/tematicheskii-katalog/research-presentations "Презентации исследований")
  - [Продукты и проекты](https://wciom.ru/tematicheskii-katalog/products-and-projects "Продукты и проекты")
  - [Награды](https://wciom.ru/tematicheskii-katalog/awards "Награды")
  - [Развитие компании](https://wciom.ru/tematicheskii-katalog/companys-development "Развитие компании")
  - [События](https://wciom.ru/tematicheskii-katalog/events "События")

- [Спорт](https://wciom.ru/tematicheskii-katalog/sport "Спорт") 4






  - [Спорт](https://wciom.ru/tematicheskii-katalog/sport "Спорт")
  - [Физическая культура](https://wciom.ru/tematicheskii-katalog/physical-culture "Физическая культура")
  - [Соревнования](https://wciom.ru/tematicheskii-katalog/competitions "Соревнования")
  - [Спортивные организации](https://wciom.ru/tematicheskii-katalog/sports-organizations "Спортивные организации")

- [Наука](https://wciom.ru/tematicheskii-katalog/science "Наука") 4






  - [Инновации](https://wciom.ru/tematicheskii-katalog/innovations "Инновации")
  - [Наука и техника](https://wciom.ru/tematicheskii-katalog/science-and-technology "Наука и техника")
  - [Социология](https://wciom.ru/tematicheskii-katalog/sociology "Социология")
  - [Робототехника](https://wciom.ru/tematicheskii-katalog/robotics-technology "Робототехника")

- [Информационные технологии](https://wciom.ru/tematicheskii-katalog/information-technology "Информационные технологии") 5






  - [Безопасность данных](https://wciom.ru/tematicheskii-katalog/data-safety "Безопасность данных")
  - [Цифровые технологии](https://wciom.ru/tematicheskii-katalog/digital-technologies "Цифровые технологии")
  - [Технологии](https://wciom.ru/tematicheskii-katalog/technologies "Технологии")
  - [Цифровизация общества](https://wciom.ru/tematicheskii-katalog/digitalization-of-society "Цифровизация общества")
  - [Искусственный интеллект](https://wciom.ru/tematicheskii-katalog/artificial-intelligence "Искусственный интеллект ")

- [Развлечения](https://wciom.ru/tematicheskii-katalog/entertainment "Развлечения") 4






  - [Досуг](https://wciom.ru/tematicheskii-katalog/leisure "Досуг")
  - [Туризм, путешествия](https://wciom.ru/tematicheskii-katalog/tourism-travelling "Туризм, путешествия")
  - [Хобби](https://wciom.ru/tematicheskii-katalog/hobby "Хобби")
  - [Активный отдых](https://wciom.ru/tematicheskii-katalog/outdoor-activities "Активный отдых")

Эксперты АЦ ВЦИОМ могут оценить стоимость исследования
и ответить на все ваши вопросы.

С нами можно связаться по почте или по телефону: [+7 495 748-08-07](tel:84957480807)