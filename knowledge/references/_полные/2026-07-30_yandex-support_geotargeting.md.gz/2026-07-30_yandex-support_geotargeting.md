Как работает геотаргетинг

# География показов

- [Как работает геотаргетинг](https://yandex.ru/support/direct/ru/efficiency/geotargeting#how-it-works)
- [Расширенный географический таргетинг](https://yandex.ru/support/direct/ru/efficiency/geotargeting#search-and-web)
  - [Как отключить расширенный географический таргетинг](https://yandex.ru/support/direct/ru/efficiency/geotargeting#kak-otklyuchit-rasshirennyj-geograficheskij-targeting)
- [Массовое редактирование регионов показа](https://yandex.ru/support/direct/ru/efficiency/geotargeting#editing)
- [Геотаргетинг в вашей первой кампании](https://yandex.ru/support/direct/ru/efficiency/geotargeting#easy-settings)
- [Уточнение регионов и детальная проработка географии](https://yandex.ru/support/direct/ru/efficiency/geotargeting#hard-settings)
- [Ограничения расширенного геотаргетинга](https://yandex.ru/support/direct/ru/efficiency/geotargeting#rules)

Эффективность рекламы в Директе зависит не только от привлекательности вашего объявления, но и от возможности конкретного человека на него отреагировать. Как правило, люди интересуются товарами и услугами в тех регионах, где они живут или куда собираются поехать.

## Как работает геотаргетинг

Геотаргетинг — это технология, позволяющая управлять географией показов вашей рекламы. Объявления Директа будут показаны только той аудитории, которая сможет воспользоваться вашим рекламным предложением, так как находится в выбранном регионе показа или интересуется им. Так, если вы доставляете пиццу только в Москве, в настройках кампании или группы объявлений выберите регион показа — Москва. Или укажите более точно регион на карте, например, улицу рядом с вашим магазином и показывайте рекламу тем, кто живет, работает или находится рядом с ним прямо сейчас.

Настроить геотаргетинг можно на уровне группы объявлений в блоке **География показов**.

Страны, области и города

Указать регион на карте

В поле **Перечислить страны, области и города**:

1. Начните вводить название, перейдите к дереву выбора регионов и отметьте регионы для показа объявлений. Установив флажок рядом с регионом, вы выбираете его целиком, включая все входящие в него населенные пункты (даже если они не указаны отдельно в дереве регионов).

В Директе можно выбрать небольшие города или регионы с населением от 1 000 человек. Чтобы настроить продвижение в таком регионе, введите его название или выберите в дереве регионов. Так вы сможете точнее настроить кампанию и найти свою аудиторию.
Как найти нужный населенный пункт



1. В настройках геотаргетинга откройте список регионов.

![](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/geotargeting-choice-region-1.png)

2. Найдите нужный населенный пункт вручную или через строку поиска и выберите его регионом показа.

![](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/geotargeting-choice-region-2.png)

2. Если необходимо, добавьте регионы, которые надо **исключить** из показа — начните вводить название области или населенного пункта в поле рядом с регионами показа. Выберите в подсказках или в дереве нужные.


Для исключения из показов можно выбрать любой доступный в настройке регион. Он может и не входить в состав указанного региона показа. Например, можно выбрать для показов Московскую область и исключить из показов Балашиху.

Дерево выбора регионов

![](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/geotargeting-choice-region.png)

Для каждой новой группы в кампании будут автоматически применены указанные в первой группе настройки регионов.

Укажите регион на карте:

- Если хотите показывать рекламу в конкретном месте, например, рядом с вашим кафе, либо вас интересуют клиенты в узкой области. Например, у вас маленький бизнес без доставки по всему городу.
- Если нужного населенного пункта нет в дереве регионов.

Стоит помнить, что выбирая регионы на карте, вы рискуете сильно сузить географию показов и потерять потенциальных клиентов.

1. Введите адреса в свободной форме или скопируйте список из другой группы — 100 штук максимум. Адреса также можно указать на карте. Определите радиус показа — от 0,5 км до 10 км около каждого адреса.

2. Укажите, кому именно вы бы хотели показывать рекламу: людям, которые бывают рядом в этом месте регулярно, живут, работают или находятся прямо сейчас. Если вы хотите охватить больше аудитории, выберите тех, кто бывает рядом регулярно, так как в эту группу входят люди, которые живут и работают рядом.


![](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/geotargeting-choice-address.png)

Заменить или удалить существующую точку можно только в группе объявлений:

- Если добавить новую точку, ранее указанные удалятся.

- Если вы указываете несколько точек одновременно и корректируете радиус, он меняется у всех точек.


## Расширенный географический таргетинг

|     |     |
| --- | --- |
| ![](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/video-icon.png) | Обучающее видео. Как работает расширенный геотаргетинг<br>Посмотреть видео<br>Как работает расширенный геотаргетинг? |

В параметрах кампании в блоке **Дополнительные настройки** по умолчанию включена опция **Расширенный географический таргетинг**. Эта опция работает на поиске Яндекса и в сетях. Она не влияет на показы объявлений на поисковых площадках РСЯ (в том числе на страницах результатов поиска по Яндекс Картам, Яндекс Маркету и другим сервисам Яндекса). [Ограничения расширенного географического таргетинга](https://yandex.ru/support/direct/ru/efficiency/geotargeting#rules).

На поиске

В сетях

Расширенный географический таргетинг позволяет показывать объявления на основе поисковых запросов и по регулярному региону пользователя.

##### **По поисковым запросам**

Для каждого запроса поиск Яндекса автоматически определяет интересующий пользователя регион. При выборе учитываются похожие, неформальные и сокращенные названия (например, Питер, Нижний, Екб).

При включенной опции система получает сигнал — сравнивать название региона из поискового запроса и региона, который вы указали в настройках группы объявлений. При совпадении этих регионов система понимает, что пользователь ищет ваш товар или услугу именно в вашем городе. О том, как настройки географии влияют на места показа объявлений, читайте в [таблице](https://yandex.ru/support/direct/ru/efficiency/geotargeting#table_1).

> Например, чтобы продвигать парк развлечений в Москве, укажите ключевую фразу _парк развлечений_ и регион показа — Москва. Такие объявления могут показываться жителям Москвы при поиске _парков развлечений_ и жителям других регионов при поиске _парков развлечений в москве_.
>
> Если житель Москвы будет искать парк развлечений в другой регионе — он может увидеть ваше объявление, потому что его местоположение будет соответствовать настройкам регионов показа в кампании.

Как сочетания настроек географии влияют на места показа ваших объявлений

|     |     |     |     |
| --- | --- | --- | --- |
|  | В кампании **включен** расширенный географический таргетинг | В кампании **включен** расширенный географический таргетинг | В кампании **отключен** расширенный географический таргетинг |
|  | Во фразе не указан регион или он **совпадает**\*\* с регионом показа | Во фразе указан регион и он **не совпадает**\*\* с регионом показа | Показ не зависит от региона во фразе |
| Пользователь находится в **регионе показа**\* | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png) | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png) | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png) |
| Пользователь находится в **другом регионе**\* | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png) (если в запросе есть название региона показа) | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png) | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png) |

\*Регион расположения пользователя, которому может быть показано объявление, сравнивается с регионом показа из настроек группы объявлений. Расположение пользователя поиска Яндекса, приложения сети или посетителя сайта сети определяется по настройкам местоположения в Яндексе или по IP-адресу.

\*\*Если более крупный регион показа из настроек объявления или кампании включает более мелкий регион из фразы, считается, что регионы совпадают (например, Россия и Москва).

Например, вы создали кампанию парка развлечений.

- Геотаргетинг: Москва и область.

Регион пользователя: пользователь находится в **Серпухове (Московская область)**.

Расширенный географический таргетинг в кампании:


|     |     |     |     |
| --- | --- | --- | --- |
| **Включен** | **Включен** | **Отключен** | **Отключен** |
| Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ | Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ |


Регион пользователя: пользователь находится в **Твери**.


|     |     |     |     |
| --- | --- | --- | --- |
| **Включен** | **Включен** | **Отключен** | **Отключен** |
| Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ | Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ |
| ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ |
| ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ |

- Геотаргетинг: Тверь.

Регион пользователя: пользователь находится в **Серпухове (Московская область)**.

Расширенный географический таргетинг в кампании:


|     |     |     |     |
| --- | --- | --- | --- |
| **Включен** | **Включен** | **Отключен** | **Отключен** |
| Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ | Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ |
| ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений москва_ |
| ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ |
| ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ |


Регион пользователя: пользователь находится в **Твери**.


|     |     |     |     |
| --- | --- | --- | --- |
| **Включен** | **Включен** | **Отключен** | **Отключен** |
| Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ | Ключевая фраза _парк развлечений_ | Ключевая фраза _парк развлечений москва_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений москва_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений_ |
| ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ | ![ok](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-ok.png)_парк развлечений ростов_ | ![cancel](https://cdn-viewer.diplodoc.com/docs-assets/support-direct-pro/rev/r20512751/ru/_assets/button-cancel.png)_парк развлечений ростов_ |


##### **По регулярному региону**

Регулярное местоположение определяется с помощью технологии [Крипта](https://yandex.ru/support/direct/ru/technologies-and-services/crypta) на основании того, как часто пользователь бывает в выбранном вами регионе. При выборе учитываются данные за последние 90 дней.

При включенной опции система получает сигнал — сравнивать регион регулярного местоположения пользователя с регионом, который вы указали в настройках объявления или кампании. Если эти данные совпадают, пользователь увидит продвижение вашего товара или услуги.

> Например, вы создали кампанию для своего автосалона в Москве, задали регион показа — Москва. Ваше объявление будет показано не только пользователям, которые находятся в Москве, но и москвичу, который заинтересован в покупке, но уехал по делам в Томск.

[Модерация](https://yandex.ru/support/direct/ru/moderation/adv-rules) объявлений проходит по правилам страны, к которой относятся настроенные вами регионы показа. При показе объявлений будут работать ограничения, предусмотренные законом о рекламе той страны, в которой должен быть показ. Возможна ситуация, когда принятое модерацией объявление не может быть показано в конкретном регионе из-за разницы в законах о рекламе.

Расширенный географический таргетинг позволяет показывать объявления пользователю с учетом его регулярного местоположения вне зависимости от того, где он находится сейчас. Регулярное местоположение определяется с помощью технологии [Крипта](https://yandex.ru/support/direct/ru/technologies-and-services/crypta) на основании того, как часто пользователь бывает в выбранном вами регионе. При выборе учитываются данные за последние 90 дней.

При включенной опции система получает сигнал — сравнивать регион регулярного местоположения пользователя с регионом, который вы указали в настройках объявления или кампании. Если эти данные совпадают, пользователь увидит рекламу вашего товара или услуги.

> Например, вы создали рекламную кампанию для своего автосалона в Москве, задали регион показа — Москва. Ваша реклама будет показана не только пользователям, которые находятся в Москве, но и москвичу, который заинтересован в покупке, но уехал по делам в Томск.

[Модерация](https://yandex.ru/support/direct/ru/moderation/adv-rules) объявлений проходит по правилам страны, к которой относятся настроенные вами регионы показа. При показе рекламы будут работать ограничения, предусмотренные законом о рекламе той страны, в которой должен быть показ. Возможна ситуация, когда принятое модерацией объявление не может быть показано в конкретном регионе из-за разницы в законах о рекламе.

Расширенный географический таргетинг не работает, если для показа указан регион на карте.

### Как отключить расширенный географический таргетинг

1. В настройках кампании перейдите в **Дополнительные настройки**.
2. Отключите опцию **Расширенный географический таргетинг**.

## Массовое редактирование регионов показа

Чтобы изменить регионы показа в нескольких группах одной или нескольких кампаний:

1. На вкладке **Кампании** выберите нужные кампании.

2. На вкладке **Группы** выберите нужные группы или отметьте все.

3. Внизу страницы нажмите **Действия** → **Регионы показа**.

4. Выберите режим изменения и укажите регионы или выберите регион на карте:
   - **Заменить** — выбранные регионы заменят текущие. Можно заменить показы в области или городе на показы в указанном регионе на карте.

   - **Добавить к списку** — выбранные регионы добавятся к текущим, например, новые адреса для регионов на карте или области в список регионов.

   - **Удалить из списка** — выбранные регионы удалятся из текущих.

## Геотаргетинг в вашей первой кампании

Чтобы быстро запустить рекламу с геотаргетингом, достаточно создать кампанию и настроить для первой группы объявлений регионы показа — те, в которых вы оказываете услуги или продаете товары. По умолчанию для этой кампании будет включен расширенный географический таргетинг.

Если вы хотите использовать ключевые фразы с названиями регионов, как это часто бывает в рекламе путешествий, туризма, отелей, гостиниц или медицинских услуг за рубежом, отключите расширенный географический таргетинг. О том, как настройки географии влияют на места показа объявлений, читайте в [таблице](https://yandex.ru/support/direct/ru/efficiency/geotargeting#table_1).

Подождите несколько дней после начала показов ваших объявлений. За это время Директ соберет статистику о количестве показов и кликов в разных регионах. Если клики распределяются по регионам неравномерно, мы рекомендуем использовать более сложную настройку регионов показа.

## Уточнение регионов и детальная проработка географии

Анализируя [статистику кликов и конверсий](https://yandex.ru/support/direct/ru/statistics/performance-stat-guide), вы можете обнаружить, что жители разных регионов по-разному реагируют на ваше рекламное предложение.

> Например, в статистике рекламы парка развлечений (ключевая фраза — _парк развлечений_, регион показа — Москва и область, расширенный географический таргетинг включен) вы заметили большое количество кликов из Москвы и Твери. В этом случае мы рекомендуем:
>
> - добавить в вашу кампанию новое объявление специально для региона показа Москва (входит в регион Москва и область);
> - создать новую кампанию специально для показов в Твери (расширенный географический таргетинг отключен, ключевая фраза _парк развлечений москва_, регион показа Тверь).

Разделение рекламных кампаний по регионам поможет вам лучше управлять ставками и сберечь бюджет: при выставлении ставок для одного региона вам не придется учитывать конкуренцию в другом. Прогноз показов для конкретного региона можно посмотреть в [Вордстате](https://wordstat.yandex.ru/).

## Ограничения расширенного геотаргетинга

Настройка расширенного геотаргетинга игнорируется для объявлений тематик «Туризм» и «Отдых» (например, отели и гостиницы, автобусные туры, путешествия, билеты на транспорт, детские лагеря и экскурсии, отзывы об отдыхе и сам отдых).

## Дарим консультацию эксперта и настройку рекламы. Бесплатно

Специалист от eLama бесплатно проведет персональную консультацию и настроит ваше продвижение в Директе при бюджете от 30 000 ₽

[Перейти в eLama](https://account.elama.global/direct/connect/yandex?&utm_source=lk_direct&utm_medium=spravka_ya&utm_campaign=consultation&utm_content=new&utm_term=new)

![](https://avatars.mds.yandex.net/get-lpc/14837328/7e803690-0a1e-48d9-8f97-43ad21fbed96/orig)

#### Остались вопросы?

Внимание

Специалисты отдела клиентского сервиса могут вас проконсультировать только по кампаниям того логина, с которого вы обращаетесь. Логин можно увидеть, если открыть [ya.ru](http://ya.ru/) на соседней вкладке браузера. Специалист получит доступ к вашим данным только при обработке обращения.

Сканируйте QR-код или нажмите на него для перехода по ссылке.

[![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/telegram-qr.png)](https://t.me/YandexDirectSupportBot?utm_source=direct&utm_medium=help&utm_campaign=ru)

[![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/watsapp-qr.png)](https://wa.me/74951399193?utm_source=direct&utm_medium=help&utm_campaign=ru)

При выборе Telegram, WhatsApp учитывайте, что Яндекс не контролирует, как сторонние мессенджеры хранят ваши данные и переписку на своей стороне, и не несет за это ответственность.

Написать в Viber

|     |     |
| --- | --- |
| [![](https://yastatic.net/s3/doc-binary/src/support/direct/ru/files/rakuten-viber-qr.png)](https://yandex.ru/support/direct/ru/efficiency/viber:/chat?service=34368) | Для обращений из Республики Беларусь |

[Написать в чат](https://yandex.ru/chat#/user/840c4ce4-ed25-4c66-a7c7-ba8c001e02d9?utm_source=pay)

Позвонить

Клиентам и представителям агентств можно связаться с нами круглосуточно по телефонам:

**Регионы России**: [8 800 700-47-45](tel:88007004745) (звонок из России бесплатный)

**Москва**: [+7 495 139-91-93](tel:+74951399193)

**Беларусь**: [+375 17 336-31-36](tel:+375173363136)

Для доступа к кампаниям специалисту потребуется [PIN-код](https://yandex.ru/support/direct/ru/troubleshooting/pin-code)

Написать письмо

Клиентам

Агентствам

Другие вопросы по Директу — Яндекс Формы

\*

### Мой текущий логин совпадает с тем логином в Директе, по которому хочу задать вопрос

### \* Ваше имя Обязательное поле

### \* Email, на который будет отправлен ответ Обязательное поле

### Номер кампании

### \* Выберите тему обращения Обязательное поле

Модерация кампании

Другие вопросы по Директу

### \* Сообщение Обязательное поле

### Присоединить файл

Загрузить

До 10 файлов, допустимый общий размер файлов — 20 МБ.

![](https://ext.captcha.yandex.net/image?key=00A0LsRmFe0uOtIqxXfgi4Xb776e9471)

Введите капчу

Отправить

[Формы обратной связи](https://yandex.ru/partner-office/knowledge-base)

### Полезные ссылки

- [Перейти в кабинет](https://direct.yandex.ru/)

- [Мои кампании](https://direct.yandex.ru/dna/grid/campaigns)

- [Вордстат](https://wordstat.yandex.ru/)

- [Способы оплаты](https://yandex.ru/support/direct/payments/payment-methods.html)

- [Контакты](https://yandex.ru/support/direct/contact-us.html)

- [Телеграм-канал Яндекс Рекламы](https://t.me/YANtech)

### Правовые документы

- [Требования к рекламным материалам](https://yandex.ru/legal/direct_adv_rules/ru/)

- [Правила показа](https://yandex.ru/legal/direct_display_rules/ru/)

- [Оферта](https://yandex.ru/legal/oferta_direct/ru/)

### Онлайн-обучение

- [Курсы по Директу](https://yandex.ru/adv/edu/online/direct)

- [Вебинары](https://yandex.ru/adv/edu/events)

- [Полезные материалы](https://yandex.ru/adv/edu/materials/tag-direct)

### Узнайте больше

- [Новости Директа](https://yandex.ru/adv/news?tag=direkt)

- [Кейсы клиентов Яндекса](https://yandex.ru/adv/solutions/cases)

- [Тренды и аналитика](https://yandex.ru/adv/solutions/analytics)

- [Мероприятия Яндекс Рекламы](https://yandex.ru/adv/meropriyatiya)

- [Телеграм-канал Яндекс Рекламы ПРО](https://t.me/yndx_ed)

### Была ли статья полезна?

ДаНет

Предыдущая

[Автотаргетинг](https://yandex.ru/support/direct/ru/impression-criteria/autotargeting)

Следующая

[Временной таргетинг](https://yandex.ru/support/direct/ru/efficiency/timetargeting)

- [Единая перфоманс-кампания](https://yandex.ru/support/direct/unified-performance-campaign/about "Единая перфоманс-кампания")
- [Реклама в мессенджерах](https://yandex.ru/support/direct/efficiency/messengers-ads "Реклама в мессенджерах")
- [Продвижение приложений](https://yandex.ru/support/direct/products-mobile-apps-ads/about "Продвижение приложений")
- [Медийная реклама](https://yandex.ru/support/direct/branding "Медийная реклама")
- [Мастер кампаний](https://yandex.ru/support/direct/campaign-master/about "Мастер кампаний")
- [Товарная кампания](https://yandex.ru/support/direct/campaign-master/product-campaign "Товарная кампания")
- [Простой старт](https://yandex.ru/support/direct/products-automatic/about "Простой старт")

- [Управление фидами](https://yandex.ru/support/direct/feeds/about "Управление фидами")
- [Таргетинги](https://yandex.ru/support/direct/impression-criteria/impression-criteria "Таргетинги")
- [Ретаргетинг](https://yandex.ru/support/direct/impression-criteria/retargeting-lists "Ретаргетинг")
- [Директ Коммандер](https://yandex.ru/support/direct/alternative-interfaces/direct-commander "Директ Коммандер")